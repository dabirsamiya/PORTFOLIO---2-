import { createContext, useContext, useEffect, type ReactNode } from "react";
import { useMotionValue, useSpring, useReducedMotion, type MotionValue } from "framer-motion";
import { useIsTouch } from "@/hooks/useMediaQuery";

type PointerCtx = {
  /** Normalised pointer position, -1..1 (springed for smooth camera-like motion). */
  px: MotionValue<number>;
  py: MotionValue<number>;
  /** Raw (unsmoothed) pointer in px */
  x: MotionValue<number>;
  y: MotionValue<number>;
  enabled: boolean;
};

const Ctx = createContext<PointerCtx | null>(null);

export function PointerProvider({ children }: { children: ReactNode }) {
  const isTouch = useIsTouch();
  const reduced = useReducedMotion();
  const enabled = !isTouch && !reduced;

  const nx = useMotionValue(0);
  const ny = useMotionValue(0);
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const px = useSpring(nx, { stiffness: 50, damping: 18, mass: 0.6 });
  const py = useSpring(ny, { stiffness: 50, damping: 18, mass: 0.6 });

  useEffect(() => {
    if (!enabled) {
      nx.set(0);
      ny.set(0);
      return;
    }
    const onMove = (e: PointerEvent) => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      x.set(e.clientX);
      y.set(e.clientY);
      nx.set((e.clientX / w) * 2 - 1);
      ny.set((e.clientY / h) * 2 - 1);
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, [enabled, nx, ny, x, y]);

  return <Ctx.Provider value={{ px, py, x, y, enabled }}>{children}</Ctx.Provider>;
}

export function usePointer() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("usePointer must be used inside <PointerProvider>");
  return ctx;
}
