import { useCallback, useState } from "react";
import { MotionConfig } from "framer-motion";
import { PointerProvider } from "@/context/PointerContext";
import { Backdrop } from "@/components/fx/Backdrop";
import { ParticleField } from "@/components/fx/ParticleField";
import { Cursor } from "@/components/fx/Cursor";
import { Preloader } from "@/components/fx/Preloader";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Hero } from "@/components/sections/Hero";
import { Statement, Marquee } from "@/components/sections/Statement";
import { Services } from "@/components/sections/Services";
import { Work } from "@/components/sections/Work";
import { Approach } from "@/components/sections/Approach";
import { Why } from "@/components/sections/Why";
import { CTA } from "@/components/sections/CTA";
import { Contact } from "@/components/sections/Contact";

export default function App() {
  const [ready, setReady] = useState(false);
  const onIntroDone = useCallback(() => setReady(true), []);

  return (
    <MotionConfig reducedMotion="user">
      <PointerProvider>
        <Preloader onDone={onIntroDone} />
        <Backdrop />
        <ParticleField />
        <Cursor />
        <Navbar />

        <main id="main" className="relative z-10">
          <Hero ready={ready} />
          <Statement />
          <Marquee />
          <Services />
          <Work />
          <Approach />
          <Why />
          <CTA />
          <Contact />
        </main>
        <div className="relative z-10">
          <Footer />
        </div>
      </PointerProvider>
    </MotionConfig>
  );
}
