import { useLayoutEffect, useState, type RefObject } from "react";

type Options = {
  /** Strings that must fit on a single line (the widest wins). */
  mustFit: string[];
  font: string; // e.g. '800 100px "Syne"'
  letterSpacingEm?: number;
  min: number;
  max: number;
  /** Safety factor applied to the computed size. */
  safety?: number;
};

/**
 * Computes the largest font-size (px) at which every `mustFit` string fits on
 * one line inside the referenced element. Re-measures on resize and once the
 * web font finishes loading, so the headline always breaks exactly as designed.
 */
export function useFitText(ref: RefObject<HTMLElement | null>, opts: Options) {
  const { mustFit, font, letterSpacingEm = 0, min, max, safety = 0.985 } = opts;
  const key = mustFit.join("|");
  const [size, setSize] = useState<number | null>(null);

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const compute = () => {
      const width = el.clientWidth;
      if (!width) return;
      ctx.font = font;
      const ref100 = 100; // font string is declared at 100px
      let widest = 0;
      for (const s of mustFit) {
        const w = ctx.measureText(s).width + letterSpacingEm * ref100 * s.length;
        widest = Math.max(widest, w);
      }
      if (!widest) return;
      const next = Math.max(min, Math.min(max, (width / widest) * ref100 * safety));
      setSize((prev) => (prev !== null && Math.abs(prev - next) < 0.5 ? prev : next));
    };

    compute();
    const ro = new ResizeObserver(compute);
    ro.observe(el);
    let cancelled = false;
    if ("fonts" in document) {
      document.fonts.load(font).then(() => !cancelled && compute()).catch(() => undefined);
      document.fonts.ready.then(() => !cancelled && compute()).catch(() => undefined);
    }
    return () => {
      cancelled = true;
      ro.disconnect();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ref, key, font, letterSpacingEm, min, max, safety]);

  return size;
}
