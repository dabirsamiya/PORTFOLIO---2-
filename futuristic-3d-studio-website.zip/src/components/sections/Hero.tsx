import { useRef, type ReactNode } from "react";
import { motion, useScroll, useTransform, type Variants } from "framer-motion";
import { usePointer } from "@/context/PointerContext";
import { useFitText } from "@/hooks/useFitText";
import { useIsDesktop } from "@/hooks/useMediaQuery";
import { featuredProject, siteConfig } from "@/config/site";
import { ButtonLink } from "@/components/ui/Button";
import { BrowserWindow } from "@/components/ui/BrowserWindow";
import { LiveFrame } from "@/components/ui/LiveFrame";
import { FloatChip } from "@/components/ui/SectionLabel";
import { Ring } from "@/components/fx/Objects3D";
import { cn } from "@/utils/cn";

const lineVariants: Variants = {
  hidden: { y: "112%", rotateX: -35 },
  show: (i: number) => ({
    y: 0,
    rotateX: 0,
    transition: { duration: 1.2, delay: 0.15 + i * 0.12, ease: [0.16, 1, 0.3, 1] },
  }),
};

const fade: Variants = {
  hidden: { opacity: 0, y: 24 },
  show: (d: number) => ({ opacity: 1, y: 0, transition: { duration: 0.9, delay: d, ease: [0.16, 1, 0.3, 1] } }),
};

function Floating({
  children,
  depth,
  className,
  parallax = 1,
}: {
  children: ReactNode;
  depth: number;
  className?: string;
  parallax?: number;
}) {
  const { px, py } = usePointer();
  const x = useTransform(px, [-1, 1], [-14 * parallax, 14 * parallax]);
  const y = useTransform(py, [-1, 1], [-10 * parallax, 10 * parallax]);
  return (
    <motion.div
      className={cn("absolute z-20", className)}
      style={{ x, y, z: depth, transformStyle: "preserve-3d" }}
    >
      <div className="animate-float" style={{ animationDelay: `${depth % 7}s` }}>
        {children}
      </div>
    </motion.div>
  );
}

const HEADLINE_FONT = '800 100px "Syne", ui-sans-serif, system-ui, sans-serif';

export function Hero({ ready }: { ready: boolean }) {
  const ref = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const isDesktop = useIsDesktop();
  // Desktop: the widest line spans the full width → exactly three lines.
  // Smaller screens: the longest single word must fit → natural wrapping, never clipped.
  const fitted = useFitText(titleRef, {
    mustFit: isDesktop ? ["THAT MAKE BUSINESSES"] : ["BUSINESSES", "EXPENSIVE."],
    font: HEADLINE_FONT,
    letterSpacingEm: -0.03,
    min: isDesktop ? 44 : 30,
    max: isDesktop ? 124 : 76,
  });
  const titleStyle = fitted ? { fontSize: `${fitted}px` } : undefined;
  const { px, py } = usePointer();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });

  // Scroll: window rises & flattens like a camera dolly, then drifts away.
  const sRotX = useTransform(scrollYProgress, [0, 0.45], [18, 0]);
  const sY = useTransform(scrollYProgress, [0, 1], [0, -160]);
  const sScale = useTransform(scrollYProgress, [0, 1], [1, 0.94]);
  const textY = useTransform(scrollYProgress, [0, 1], [0, 140]);
  const textOpacity = useTransform(scrollYProgress, [0, 0.6], [1, 0]);

  // Mouse: gentle orbit around the object.
  const mRotY = useTransform(px, [-1, 1], [-7, 7]);
  const mRotX = useTransform(py, [-1, 1], [4, -4]);
  const rotateX = useTransform(() => sRotX.get() + mRotX.get());
  const rotateY = useTransform(() => -4 + mRotY.get());

  // 3D shadow text follows the pointer at a different depth.
  const shadowX = useTransform(px, [-1, 1], [22, -22]);
  const shadowY = useTransform(py, [-1, 1], [16, -16]);

  const lines: ReactNode[] = ["I design websites", "that make businesses", <span className="text-metal">look expensive.</span>];

  return (
    <section
      id="top"
      ref={ref}
      aria-labelledby="hero-title"
      className="relative overflow-hidden pt-32 pb-16 sm:pt-40 md:pb-28"
    >
      {/* Perspective floor */}
      <div aria-hidden="true" className="perspective-near pointer-events-none absolute inset-x-[-20%] top-[58%] h-[70vh] sm:top-[52%]">
        <div className="floor-grid h-full w-full animate-grid-drift" style={{ transform: "rotateX(74deg)" }} />
      </div>
      <Ring size={520} className="left-[-160px] top-[62%] opacity-60" blur={2} />
      <Ring size={260} className="right-[-60px] top-[28%] opacity-40" blur={3} />

      <div className="relative mx-auto max-w-[1440px] px-5 sm:px-8">
        {/* Eyebrow */}
        <motion.div
          variants={fade}
          custom={0.05}
          initial="hidden"
          animate={ready ? "show" : "hidden"}
          className="mb-8 flex flex-wrap items-center gap-x-5 gap-y-2 sm:mb-10"
        >
          <span className="inline-flex items-center gap-2.5 font-mono text-[0.68rem] tracking-[0.34em] text-frost uppercase">
            <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-electric shadow-[0_0_14px_#5b8cff]" />
            {siteConfig.name}
          </span>
          <span className="hidden h-px w-10 bg-white/15 sm:block" />
          <span className="eyebrow">{siteConfig.role}</span>
        </motion.div>

        {/* Headline with 3D depth shadow */}
        <motion.div style={{ y: textY, opacity: textOpacity }} className="perspective-far relative">
          <motion.p
            aria-hidden="true"
            className="display pointer-events-none absolute inset-0 select-none text-[clamp(2rem,5vw,4.6rem)] text-white/[0.06] blur-[3px]"
            style={{ x: shadowX, y: shadowY, z: -120, ...titleStyle }}
          >
            {["I design websites", "that make businesses", "look expensive."].map((l) => (
              <span key={l} className="block">
                {l}
              </span>
            ))}
          </motion.p>
          <h1
            id="hero-title"
            ref={titleRef}
            className="display relative text-[clamp(2rem,5vw,4.6rem)] text-frost"
            style={titleStyle}
          >
            {lines.map((line, i) => (
              <span key={i} className="block overflow-hidden pb-[0.1em] -mb-[0.1em]">
                <motion.span
                  className="block will-change-transform"
                  variants={lineVariants}
                  custom={i}
                  initial="hidden"
                  animate={ready ? "show" : "hidden"}
                  style={{ transformOrigin: "0% 100%" }}
                >
                  {line}
                </motion.span>
              </span>
            ))}
          </h1>
        </motion.div>

        {/* Supporting row */}
        <motion.div
          style={{ opacity: textOpacity }}
          className="mt-10 flex flex-col gap-8 md:mt-12 md:flex-row md:items-end md:justify-between"
        >
          <motion.p
            variants={fade}
            custom={0.55}
            initial="hidden"
            animate={ready ? "show" : "hidden"}
            className="max-w-md text-base leading-relaxed text-fog sm:text-lg"
          >
            Websites that combine strategy, design and technology to give businesses a stronger digital presence.
          </motion.p>
          <motion.div
            variants={fade}
            custom={0.7}
            initial="hidden"
            animate={ready ? "show" : "hidden"}
            className="flex flex-wrap items-center gap-4"
          >
            <ButtonLink href="#work" variant="primary">
              Explore my work
            </ButtonLink>
            <ButtonLink href="#contact" variant="outline">
              Start a project
            </ButtonLink>
          </motion.div>
        </motion.div>

        {/* Floating 3D browser */}
        <motion.div
          initial={{ opacity: 0, y: 140 }}
          animate={ready ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1.6, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="perspective-far relative mx-auto mt-14 w-full max-w-[1120px] sm:mt-16 lg:mt-14"
        >
          <BrowserWindow
            url={featuredProject.url}
            depth={22}
            style={{ rotateX, rotateY, y: sY, scale: sScale, transformOrigin: "50% 100%" }}
            float={
              <>
                <Floating depth={110} parallax={1.4} className="left-[2%] top-[14%] sm:left-[-6%]">
                  <FloatChip>Design</FloatChip>
                </Floating>
                <Floating depth={150} parallax={1.9} className="right-[-3%] top-[36%] hidden sm:block sm:right-[-7%]">
                  <FloatChip dot="bg-violet">Development</FloatChip>
                </Floating>
                <Floating depth={80} parallax={1.1} className="bottom-[10%] right-[4%] sm:right-auto sm:left-[4%]">
                  <FloatChip dot="bg-white">Responsive</FloatChip>
                </Floating>
                <Floating depth={130} parallax={1.6} className="right-[8%] top-[-4%] hidden sm:block sm:right-[10%]">
                  <FloatChip>Conversion</FloatChip>
                </Floating>
              </>
            }
          >
            <LiveFrame
              url={featuredProject.url}
              name={featuredProject.name}
              palette={featuredProject.palette}
              delay={900}
            />
          </BrowserWindow>
        </motion.div>
      </div>

      {/* Scroll cue */}
      <motion.div
        variants={fade}
        custom={1.4}
        initial="hidden"
        animate={ready ? "show" : "hidden"}
        aria-hidden="true"
        className="pointer-events-none absolute left-8 top-[calc(100svh-5.5rem)] hidden flex-col items-center gap-3 lg:flex"
      >
        <span className="eyebrow text-[0.58rem]">Scroll</span>
        <span className="relative h-10 w-px overflow-hidden bg-white/10">
          <motion.span
            className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-transparent via-electric to-transparent"
            animate={{ y: ["-100%", "220%"] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          />
        </span>
      </motion.div>
    </section>
  );
}
