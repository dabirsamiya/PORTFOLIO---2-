import { useRef } from "react";
import { motion, useScroll, useTransform, type MotionValue } from "framer-motion";
import { Reveal } from "@/components/ui/Reveal";
import { SectionLabel } from "@/components/ui/SectionLabel";

const WORDS = ["Your", "website", "is", "your", "first", "impression."];

function Word({ word, index, total, progress }: { word: string; index: number; total: number; progress: MotionValue<number> }) {
  const start = index / total;
  const end = (index + 1) / total;
  const opacity = useTransform(progress, [start, end], [0.12, 1]);
  const y = useTransform(progress, [start, end], [18, 0]);
  const blur = useTransform(progress, [start, end], ["blur(6px)", "blur(0px)"]);
  const isAccent = index >= 4;
  return (
    <motion.span
      className={isAccent ? "text-metal inline-block" : "inline-block"}
      style={{ opacity, y, filter: blur }}
    >
      {word}
      {index < total - 1 && "\u00A0"}
    </motion.span>
  );
}

export function Statement() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 85%", "end 55%"] });
  const rotateX = useTransform(scrollYProgress, [0, 1], [16, 0]);
  const z = useTransform(scrollYProgress, [0, 1], [-160, 0]);

  return (
    <section ref={ref} aria-labelledby="statement-title" className="relative overflow-hidden py-28 md:py-44">
      <div className="mx-auto max-w-[1440px] px-5 sm:px-8">
        <SectionLabel index="00" className="mb-12">
          Statement
        </SectionLabel>
        <div className="perspective-far">
          <motion.h2
            id="statement-title"
            className="display max-w-[1200px] text-[clamp(2.6rem,7.4vw,8.6rem)] text-frost"
            style={{ rotateX, z, transformOrigin: "50% 100%", transformStyle: "preserve-3d" }}
          >
            {WORDS.map((w, i) => (
              <Word key={w + i} word={w} index={i} total={WORDS.length} progress={scrollYProgress} />
            ))}
          </motion.h2>
        </div>
        <div className="mt-14 grid gap-10 md:grid-cols-12">
          <div className="hidden md:col-span-5 md:block">
            <Reveal delay={0.1}>
              <div className="flex items-center gap-4">
                <span className="h-px w-16 bg-gradient-to-r from-electric to-transparent" />
                <span className="eyebrow">Modern digital experiences</span>
              </div>
            </Reveal>
          </div>
          <div className="md:col-span-6 md:col-start-7">
            <Reveal delay={0.2}>
              <p className="max-w-xl text-lg leading-relaxed text-fog sm:text-xl md:text-2xl md:leading-snug">
                I create modern digital experiences for businesses that want to look{" "}
                <span className="text-frost">professional</span>, <span className="text-frost">credible</span> and{" "}
                <span className="text-frost">memorable</span> online.
              </p>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

const MARQUEE = [
  "Business Websites",
  "Salon & Beauty",
  "Landing Pages",
  "Restaurant & Café",
  "Academy & Courses",
  "Website Redesigns",
];

export function Marquee() {
  const items = [...MARQUEE, ...MARQUEE];
  return (
    <div aria-hidden="true" className="relative overflow-hidden border-y border-white/[0.06] py-5">
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-ink to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-ink to-transparent" />
      <div className="flex w-max animate-marquee gap-10 whitespace-nowrap will-change-transform">
        {items.map((item, i) => (
          <span key={i} className="flex items-center gap-10 font-display text-sm font-bold uppercase tracking-[0.18em] text-fog/80">
            {item}
            <span className="h-1 w-1 rounded-full bg-electric/70" />
          </span>
        ))}
      </div>
    </div>
  );
}
