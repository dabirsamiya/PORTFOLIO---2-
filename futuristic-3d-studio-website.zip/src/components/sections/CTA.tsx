import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { usePointer } from "@/context/PointerContext";
import { hasWhatsApp, whatsappLink } from "@/config/site";
import { ButtonLink } from "@/components/ui/Button";
import { RevealLines, Reveal } from "@/components/ui/Reveal";
import { Cube3D, Gyro, Ring } from "@/components/fx/Objects3D";

export function CTA() {
  const ref = useRef<HTMLElement>(null);
  const { px, py } = usePointer();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });

  const orbY = useTransform(scrollYProgress, [0, 1], [120, -120]);
  const orbX = useTransform(px, [-1, 1], [-30, 30]);
  const cubeX = useTransform(px, [-1, 1], [40, -40]);
  const cubeY = useTransform(py, [-1, 1], [24, -24]);
  const gyroX = useTransform(px, [-1, 1], [-24, 24]);
  const gyroY = useTransform(scrollYProgress, [0, 1], [60, -160]);
  const whatsapp = hasWhatsApp();

  return (
    <section ref={ref} aria-labelledby="cta-title" className="relative overflow-hidden py-36 md:py-56">
      {/* Floor + light */}
      <div aria-hidden="true" className="perspective-near pointer-events-none absolute inset-x-[-20%] top-[45%] h-[80vh]">
        <div className="floor-grid h-full w-full animate-grid-drift" style={{ transform: "rotateX(76deg)" }} />
      </div>
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-1/2 h-[70vmin] w-[70vmin] -translate-x-1/2 -translate-y-1/2 rounded-full"
        style={{
          x: orbX,
          y: orbY,
          background:
            "radial-gradient(circle, rgba(91,140,255,0.22) 0%, rgba(139,108,255,0.10) 35%, transparent 65%)",
        }}
      />
      <Ring size={720} className="left-1/2 top-[70%] -translate-x-1/2 opacity-70" />
      <Ring size={420} className="left-1/2 top-[70%] -translate-x-1/2 opacity-50" blur={1} />

      {/* Floating geometry */}
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute left-[6%] top-[18%] hidden md:block"
        style={{ x: cubeX, y: cubeY }}
      >
        <div className="animate-float-slow">
          <Cube3D size={70} />
        </div>
      </motion.div>
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute right-[5%] top-[22%] hidden md:block"
        style={{ x: gyroX, y: gyroY }}
      >
        <Gyro size={190} />
      </motion.div>
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute bottom-[14%] right-[18%] hidden lg:block"
        style={{ x: cubeY, y: cubeX }}
      >
        <div className="animate-float blur-[1.5px]">
          <Cube3D size={36} />
        </div>
      </motion.div>

      <div className="relative mx-auto flex max-w-[1440px] flex-col items-center px-5 text-center sm:px-8">
        <Reveal>
          <span className="eyebrow mb-8 inline-block">Let's talk</span>
        </Reveal>
        <RevealLines
          id="cta-title"
          as="h2"
          className="display text-[clamp(2.8rem,8vw,9rem)] text-frost"
          lineClassName="mx-auto"
          lines={["Ready to build", <span className="text-metal">something better?</span>]}
          fit={{ longest: "something better?", max: 144 }}
        />
        <Reveal delay={0.25}>
          <p className="mx-auto mt-8 max-w-lg text-base leading-relaxed text-fog sm:text-lg">
            Tell me about your business and let's create a website that makes people take you seriously.
          </p>
        </Reveal>
        <Reveal delay={0.35}>
          <div className="mt-12 flex flex-wrap items-center justify-center gap-4">
            <ButtonLink href="#contact" variant="primary">
              Start your project
            </ButtonLink>
            <ButtonLink
              href={whatsappLink()}
              variant="outline"
              title={whatsapp ? "Chat on WhatsApp" : "WhatsApp number not configured yet — opens the contact form"}
            >
              WhatsApp me
            </ButtonLink>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
