import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { motion, useMotionValue, useMotionValueEvent, useScroll, useSpring, useTransform } from "framer-motion";
import { useIsDesktop } from "@/hooks/useMediaQuery";
import { Cube3D } from "@/components/fx/Objects3D";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { Reveal, RevealLines } from "@/components/ui/Reveal";
import { cn } from "@/utils/cn";

const STEPS = [
  { n: "01", title: "Discover", text: "Understand the business, audience and goals." },
  { n: "02", title: "Design", text: "Create the visual direction and user experience." },
  { n: "03", title: "Build", text: "Develop a responsive, functional website." },
  { n: "04", title: "Launch", text: "Deploy the website and make it ready for customers." },
];

type Pt = { x: number; y: number };

/** Layout-space offset of `el` relative to `ancestor` (unaffected by CSS 3D transforms). */
function offsetWithin(el: HTMLElement, ancestor: HTMLElement) {
  let left = 0;
  let top = 0;
  let node: HTMLElement | null = el;
  while (node && node !== ancestor) {
    left += node.offsetLeft;
    top += node.offsetTop;
    node = node.offsetParent as HTMLElement | null;
  }
  return { left, top };
}

function buildPath(points: Pt[], lead = 70) {
  if (points.length === 0) return "";
  const first = points[0];
  const last = points[points.length - 1];
  let d = `M ${first.x} ${first.y - lead} L ${first.x} ${first.y}`;
  for (let i = 0; i < points.length - 1; i++) {
    const a = points[i];
    const b = points[i + 1];
    const dy = (b.y - a.y) * 0.5;
    d += ` C ${a.x} ${a.y + dy}, ${b.x} ${b.y - dy}, ${b.x} ${b.y}`;
  }
  d += ` L ${last.x} ${last.y + lead}`;
  return d;
}

export function Approach() {
  const sectionRef = useRef<HTMLElement>(null);
  const railRef = useRef<HTMLDivElement>(null);
  const pathRef = useRef<SVGPathElement>(null);
  const nodeRefs = useRef<(HTMLDivElement | null)[]>([]);
  const isDesktop = useIsDesktop();

  const [box, setBox] = useState({ w: 0, h: 0 });
  const [points, setPoints] = useState<Pt[]>([]);
  const [active, setActive] = useState(-1);

  const measure = useCallback(() => {
    const rail = railRef.current;
    if (!rail) return;
    const pts: Pt[] = [];
    nodeRefs.current.forEach((el) => {
      if (!el) return;
      const { left, top } = offsetWithin(el, rail);
      pts.push({ x: left + el.offsetWidth / 2, y: top + el.offsetHeight / 2 });
    });
    setBox({ w: rail.offsetWidth, h: rail.offsetHeight });
    setPoints(pts);
  }, []);

  useLayoutEffect(() => {
    measure();
    const ro = new ResizeObserver(() => measure());
    if (railRef.current) ro.observe(railRef.current);
    window.addEventListener("resize", measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, [measure]);

  useEffect(() => {
    const id = requestAnimationFrame(measure);
    return () => cancelAnimationFrame(id);
  }, [isDesktop, measure]);

  const d = useMemo(() => buildPath(points), [points]);

  const { scrollYProgress } = useScroll({ target: railRef, offset: ["start 72%", "end 60%"] });
  const progress = useSpring(scrollYProgress, { stiffness: 90, damping: 24, mass: 0.4 });

  const ox = useMotionValue(0);
  const oy = useMotionValue(0);
  const [len, setLen] = useState(0);

  useEffect(() => {
    if (pathRef.current) setLen(pathRef.current.getTotalLength());
  }, [d]);

  useMotionValueEvent(progress, "change", (v) => {
    const path = pathRef.current;
    if (!path || !len) return;
    const p = path.getPointAtLength(Math.max(0, Math.min(1, v)) * len);
    ox.set(p.x);
    oy.set(p.y);
    let idx = -1;
    points.forEach((pt, i) => {
      if (p.y >= pt.y - 6) idx = i;
    });
    setActive((prev) => (prev === idx ? prev : idx));
  });

  const tilt = useTransform(scrollYProgress, [0, 1], [8, -4]);

  return (
    <section id="process" ref={sectionRef} aria-labelledby="process-title" className="relative overflow-hidden py-28 md:py-40">
      <div className="mx-auto max-w-[1440px] px-5 sm:px-8">
        <div className="mb-20 md:mb-28">
          <SectionLabel index="03" className="mb-8">
            My approach
          </SectionLabel>
          <RevealLines
            id="process-title"
            as="h2"
            className="display text-[clamp(2.5rem,6.4vw,7rem)] text-frost"
            lines={["From idea", <span className="text-metal">to live website.</span>]}
            fit={{ longest: "to live website.", max: 112 }}
          />
          <div className="mt-10 md:flex md:justify-end">
            <Reveal delay={0.2}>
              <p className="max-w-sm text-base leading-relaxed text-fog">
                A clear four-step process from first conversation to a website that's live and ready for customers.
              </p>
            </Reveal>
          </div>
        </div>

        {/* Timeline stage */}
        <div className="perspective-far">
          <motion.div
            ref={railRef}
            className="preserve-3d relative"
            style={{ rotateX: tilt, transformOrigin: "50% 50%" }}
          >
            {/* Path layers */}
            {box.w > 0 && d && (
              <>
                <svg
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-0 h-full w-full overflow-visible"
                  width={box.w}
                  height={box.h}
                  viewBox={`0 0 ${box.w} ${box.h}`}
                  style={{ transform: "translateZ(-70px)" }}
                >
                  <path d={d} fill="none" stroke="rgba(91,140,255,0.08)" strokeWidth="14" strokeLinecap="round" />
                </svg>
                <svg
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-0 h-full w-full overflow-visible"
                  width={box.w}
                  height={box.h}
                  viewBox={`0 0 ${box.w} ${box.h}`}
                >
                  <defs>
                    <linearGradient id="rail-grad" x1="0" y1="0" x2="0" y2="1">
                      <stop stopColor="#ffffff" />
                      <stop offset="0.5" stopColor="#5b8cff" />
                      <stop offset="1" stopColor="#8b6cff" />
                    </linearGradient>
                  </defs>
                  <path ref={pathRef} d={d} fill="none" stroke="rgba(255,255,255,0.10)" strokeWidth="1.5" />
                  <motion.path
                    d={d}
                    fill="none"
                    stroke="url(#rail-grad)"
                    strokeWidth="2"
                    strokeLinecap="round"
                    style={{ pathLength: progress }}
                  />
                </svg>
                {/* Travelling object */}
                <motion.div
                  aria-hidden="true"
                  className="pointer-events-none absolute left-0 top-0 z-20"
                  style={{ x: ox, y: oy, translateX: "-50%", translateY: "-50%", z: 40 }}
                >
                  <div className="relative h-4 w-4">
                    <span className="absolute -inset-10 rounded-full bg-[radial-gradient(circle,rgba(91,140,255,0.35),transparent_60%)]" />
                    <span className="absolute -inset-3 animate-spin-slow rounded-full border border-dashed border-electric/50" />
                    <span className="absolute inset-0 rounded-full bg-white shadow-[0_0_24px_6px_rgba(91,140,255,0.55)]" />
                  </div>
                </motion.div>
              </>
            )}

            {/* Steps */}
            <ol className="relative space-y-10 md:space-y-16">
              {STEPS.map((s, i) => {
                const left = i % 2 === 0;
                const isActive = i <= active;
                return (
                  <li
                    key={s.n}
                    className="grid grid-cols-[64px_1fr] items-center gap-4 sm:grid-cols-[88px_1fr] md:grid-cols-[1fr_180px_1fr] md:gap-0"
                  >
                    {/* Left slot (desktop) */}
                    <div className={cn("hidden md:block", left ? "md:pr-6" : "")}>
                      {left && <StepCard step={s} active={isActive} align="right" index={i} />}
                    </div>

                    {/* Node */}
                    <div className="flex items-center justify-center md:justify-center">
                      <div
                        ref={(el) => {
                          nodeRefs.current[i] = el;
                        }}
                        className="flex items-center justify-center"
                        style={{
                          transform: `translateZ(${isActive ? 30 : 0}px)`,
                          // Alternate nodes left/right on desktop so the path becomes a real S-curve
                          // (margins shift layout position, which the path measurement reads).
                          marginLeft: isDesktop ? (left ? -84 : 84) : 0,
                        }}
                      >
                        <Cube3D size={isDesktop ? 56 : 40} active={isActive} label={s.n} />
                      </div>
                    </div>

                    {/* Right slot (desktop) / all cards on mobile */}
                    <div className={cn("md:pl-6", !left ? "" : "md:hidden")}>
                      <StepCard step={s} active={isActive} align="left" index={i} />
                    </div>
                  </li>
                );
              })}
            </ol>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function StepCard({
  step,
  active,
  align,
  index,
}: {
  step: (typeof STEPS)[number];
  active: boolean;
  align: "left" | "right";
  index: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: align === "right" ? -40 : 40 }}
      whileInView={{ opacity: 1, x: 0 }}
      animate={{ z: active ? 50 : 0 }}
      viewport={{ once: true, amount: 0.5 }}
      transition={{ duration: 0.9, delay: 0.1 + index * 0.05, ease: [0.16, 1, 0.3, 1] }}
      className={cn(
        "glass metal-edge relative max-w-md rounded-[8px] p-6 transition-[border-color,background-color,box-shadow] duration-700 ease-out-expo sm:p-8",
        align === "right" ? "ml-auto text-right" : "",
        active ? "border-electric/40 bg-white/[0.06] shadow-[0_30px_70px_-30px_rgba(91,140,255,0.45)]" : "",
      )}
      style={{ transformStyle: "preserve-3d" }}
    >
      <span
        aria-hidden="true"
        className={cn(
          "absolute top-0 h-px w-2/3 bg-gradient-to-r from-electric to-transparent transition-opacity duration-700",
          align === "right" ? "right-0 bg-gradient-to-l" : "left-0",
          active ? "opacity-100" : "opacity-0",
        )}
      />
      <div className={cn("flex items-center gap-3", align === "right" && "justify-end")}>
        <span className="font-mono text-[0.66rem] tracking-[0.3em] text-electric">{step.n}</span>
        <span className="h-px w-6 bg-white/15" />
        <span className={cn("eyebrow transition-colors duration-500", active ? "text-frost" : "")}>Step</span>
      </div>
      <h3 className="display mt-4 text-[1.9rem] text-frost sm:text-[2.3rem]">{step.title}</h3>
      <p className="mt-3 text-sm leading-relaxed text-fog sm:text-base">{step.text}</p>
    </motion.div>
  );
}
