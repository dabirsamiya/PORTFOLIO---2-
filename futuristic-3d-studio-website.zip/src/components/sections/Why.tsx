import { motion } from "framer-motion";
import { TiltCard } from "@/components/ui/TiltCard";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { Reveal, RevealLines } from "@/components/ui/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { Cube3D, Gyro, Layers3D } from "@/components/fx/Objects3D";

const PANELS = [
  {
    n: "01",
    title: "First impressions matter",
    text: "A professional website builds trust before a customer ever contacts you.",
    object: <Gyro size={150} />,
  },
  {
    n: "02",
    title: "Built for real businesses",
    text: "Every website is designed around the business rather than a generic template.",
    object: <Layers3D width={150} />,
  },
  {
    n: "03",
    title: "Design + Function",
    text: "Beautiful visuals are combined with practical navigation and strong calls to action.",
    object: <Cube3D size={80} className="my-8" />,
  },
];

export function Why() {
  return (
    <section id="about" aria-labelledby="about-title" className="relative overflow-hidden py-28 md:py-40">
      <div className="mx-auto max-w-[1440px] px-5 sm:px-8">
        <div className="mb-16 md:mb-24">
          <SectionLabel index="04" className="mb-8">
            Why work with me
          </SectionLabel>
          <RevealLines
            id="about-title"
            as="h2"
            className="display text-[clamp(2.5rem,6.4vw,7rem)] text-frost"
            lines={["Designed to", <span className="text-metal">make you stand out.</span>]}
            fit={{ longest: "make you stand out.", max: 112 }}
          />
          <div className="mt-10 md:flex md:justify-end">
            <Reveal delay={0.2}>
              <p className="max-w-sm text-base leading-relaxed text-fog">
                Premium design, thoughtful structure and a website that helps your business look as good as it is.
              </p>
            </Reveal>
          </div>
        </div>

        <ul className="grid gap-5 lg:grid-cols-3" role="list">
          {PANELS.map((p, i) => (
            <motion.li
              key={p.n}
              className="list-none"
              initial={{ opacity: 0, y: 70, rotateX: 14 }}
              whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 1.1, delay: i * 0.12, ease: [0.16, 1, 0.3, 1] }}
              style={{ transformOrigin: "50% 100%" }}
            >
              <TiltCard className="h-full" maxTilt={6} lift={20} innerClassName="rounded-[10px]">
                <article className="glass metal-edge group relative flex h-full min-h-[440px] flex-col overflow-hidden rounded-[10px] p-8 transition-colors duration-500 hover:border-white/20 sm:p-10">
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-700 group-hover:opacity-100"
                    style={{
                      background:
                        "radial-gradient(420px circle at var(--mx,50%) var(--my,50%), rgba(139,108,255,0.16), transparent 55%)",
                    }}
                  />
                  <span
                    aria-hidden="true"
                    className="display pointer-events-none absolute -right-3 -top-6 select-none text-[7rem] leading-none text-outline opacity-50"
                  >
                    {p.n}
                  </span>
                  <div className="relative flex min-h-[190px] items-center justify-center" style={{ transform: "translateZ(50px)" }}>
                    {p.object}
                  </div>
                  <div className="relative mt-auto" style={{ transform: "translateZ(30px)" }}>
                    <span className="font-mono text-[0.66rem] tracking-[0.3em] text-electric">{p.n}</span>
                    <h3 className="display mt-4 max-w-[12ch] text-[1.7rem] leading-[1] text-frost sm:text-[2rem]">{p.title}</h3>
                    <p className="mt-4 max-w-[34ch] text-sm leading-relaxed text-fog sm:text-base">{p.text}</p>
                  </div>
                </article>
              </TiltCard>
            </motion.li>
          ))}
        </ul>

        <Reveal className="mt-14 flex justify-center" delay={0.2}>
          <ButtonLink href="#contact" variant="outline">
            Build my website
          </ButtonLink>
        </Reveal>
      </div>
    </section>
  );
}
