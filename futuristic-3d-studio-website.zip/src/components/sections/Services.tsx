import type { ReactNode } from "react";
import { motion } from "framer-motion";
import { TiltCard } from "@/components/ui/TiltCard";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { RevealLines, Reveal } from "@/components/ui/Reveal";

type Service = { index: string; title: string; description: string; glyph: ReactNode };

const glyphProps = {
  viewBox: "0 0 48 48",
  fill: "none",
  stroke: "url(#svc-gradient)",
  strokeWidth: 1.4,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  className: "h-12 w-12",
  "aria-hidden": true,
};

const SERVICES: Service[] = [
  {
    index: "01",
    title: "Business Websites",
    description: "Professional websites designed to establish trust and turn visitors into enquiries.",
    glyph: (
      <svg {...glyphProps}>
        <rect x="6" y="9" width="36" height="30" rx="2" />
        <path d="M6 16h36M11 12.5h.01M15 12.5h.01" />
        <path d="M12 24h12M12 29h18M12 34h8" />
      </svg>
    ),
  },
  {
    index: "02",
    title: "Salon & Beauty Websites",
    description: "Elegant, visual websites designed for salons, beauty studios and aesthetic businesses.",
    glyph: (
      <svg {...glyphProps}>
        <path d="M24 6c1.2 9.5 3.5 12 18 18-14.5 6-16.8 8.5-18 18-1.2-9.5-3.5-12-18-18 14.5-6 16.8-8.5 18-18Z" />
        <path d="M37 6l.8 3.2L41 10l-3.2.8L37 14l-.8-3.2L33 10l3.2-.8L37 6Z" />
      </svg>
    ),
  },
  {
    index: "03",
    title: "Landing Pages",
    description: "Focused landing pages built around clear messaging and strong calls to action.",
    glyph: (
      <svg {...glyphProps}>
        <path d="M24 6v24M15 21l9 9 9-9" />
        <path d="M8 40h32M12 36h24" />
      </svg>
    ),
  },
  {
    index: "04",
    title: "Restaurant & Café Websites",
    description: "Modern food and hospitality websites designed to showcase menus, atmosphere and experiences.",
    glyph: (
      <svg {...glyphProps}>
        <path d="M10 20h24v9a9 9 0 0 1-9 9h-6a9 9 0 0 1-9-9v-9Z" />
        <path d="M34 23h3a4.5 4.5 0 0 1 0 9h-3" />
        <path d="M17 7c-2 3 2 4 0 7M23 7c-2 3 2 4 0 7M29 7c-2 3 2 4 0 7" />
        <path d="M8 42h32" />
      </svg>
    ),
  },
  {
    index: "05",
    title: "Academy & Course Websites",
    description: "Structured websites for academies, workshops, online courses and student experiences.",
    glyph: (
      <svg {...glyphProps}>
        <path d="M4 19 24 10l20 9-20 9L4 19Z" />
        <path d="M12 23v9c0 3 6 6 12 6s12-3 12-6v-9" />
        <path d="M44 19v11" />
      </svg>
    ),
  },
  {
    index: "06",
    title: "Website Redesigns",
    description: "Transform outdated websites into modern, responsive digital experiences.",
    glyph: (
      <svg {...glyphProps}>
        <path d="M40 24a16 16 0 0 1-28 10.6M8 24A16 16 0 0 1 36 13.4" />
        <path d="M36 6v8h-8M12 42v-8h8" />
      </svg>
    ),
  },
];

function ServiceCard({ service, i }: { service: Service; i: number }) {
  return (
    <motion.li
      initial={{ opacity: 0, y: 60, rotateX: 12 }}
      whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
      viewport={{ once: true, amount: 0.25 }}
      transition={{ duration: 1, delay: (i % 3) * 0.1, ease: [0.16, 1, 0.3, 1] }}
      className="h-full list-none"
      style={{ transformOrigin: "50% 100%" }}
    >
      <TiltCard className="h-full" maxTilt={7} lift={18} innerClassName="rounded-[8px]">
        <article className="glass metal-edge group relative flex h-full min-h-[300px] flex-col overflow-hidden rounded-[8px] p-7 transition-[border-color] duration-500 hover:border-white/20 sm:p-8">
          {/* pointer light */}
          <span
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
            style={{
              background:
                "radial-gradient(360px circle at var(--mx,50%) var(--my,50%), rgba(91,140,255,0.16), transparent 55%)",
            }}
          />
          <div className="relative flex items-start justify-between" style={{ transform: "translateZ(30px)" }}>
            <span className="font-mono text-[0.68rem] tracking-[0.3em] text-electric">{service.index}</span>
            <span className="text-frost/90 transition-transform duration-700 ease-out-expo group-hover:-translate-y-1 group-hover:scale-110">
              {service.glyph}
            </span>
          </div>
          <h3
            className="display mt-auto max-w-[11ch] pt-10 text-[1.55rem] leading-[1] tracking-[-0.02em] text-frost sm:text-[1.7rem]"
            style={{ transform: "translateZ(40px)" }}
          >
            {service.title}
          </h3>
          <p
            className="mt-4 max-w-[30ch] text-sm leading-relaxed text-fog/70 transition-all duration-700 ease-out-expo group-hover:translate-y-0 group-hover:text-fog sm:translate-y-1.5 sm:opacity-60 sm:group-hover:opacity-100"
            style={{ transform: "translateZ(24px)" }}
          >
            {service.description}
          </p>
          <span
            aria-hidden="true"
            className="mt-6 block h-px w-8 bg-gradient-to-r from-electric to-violet transition-all duration-700 ease-out-expo group-hover:w-full"
          />
        </article>
      </TiltCard>
    </motion.li>
  );
}

export function Services() {
  return (
    <section id="services" aria-labelledby="services-title" className="relative py-28 md:py-40">
      <svg aria-hidden="true" width="0" height="0" className="absolute">
        <defs>
          <linearGradient id="svc-gradient" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
            <stop stopColor="#ffffff" />
            <stop offset="0.55" stopColor="#5b8cff" />
            <stop offset="1" stopColor="#8b6cff" />
          </linearGradient>
        </defs>
      </svg>
      <div className="mx-auto max-w-[1440px] px-5 sm:px-8">
        <div className="mb-16 flex flex-col gap-8 md:mb-20 md:flex-row md:items-end md:justify-between">
          <div>
            <SectionLabel index="01" className="mb-8">
              Services
            </SectionLabel>
            <RevealLines
              id="services-title"
              as="h2"
              className="display text-[clamp(2.4rem,6vw,6.4rem)] text-frost"
              lines={["What", <span className="text-metal">I build</span>]}
            />
          </div>
          <Reveal delay={0.2}>
            <p className="max-w-sm text-base leading-relaxed text-fog md:text-right">
              Six kinds of websites, one standard: premium design that works as hard as the business behind it.
            </p>
          </Reveal>
        </div>

        <ul className="grid gap-4 md:grid-cols-2 lg:grid-cols-3" role="list">
          {SERVICES.map((s, i) => (
            <ServiceCard key={s.index} service={s} i={i} />
          ))}
        </ul>
      </div>
    </section>
  );
}
