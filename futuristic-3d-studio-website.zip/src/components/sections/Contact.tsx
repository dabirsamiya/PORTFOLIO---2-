import { useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import {
  emailLink,
  hasEmail,
  hasInstagram,
  hasWhatsApp,
  instagramLink,
  siteConfig,
  whatsappLink,
} from "@/config/site";
import { Button } from "@/components/ui/Button";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { Reveal, RevealLines } from "@/components/ui/Reveal";
import { TiltCard } from "@/components/ui/TiltCard";
import { cn } from "@/utils/cn";

type Channel = { key: string; label: string; value: string; href: string; configured: boolean; icon: React.ReactNode };

const iconCls = "h-5 w-5";

function useChannels(): Channel[] {
  const { contact } = siteConfig;
  return [
    {
      key: "whatsapp",
      label: "WhatsApp",
      configured: hasWhatsApp(),
      value: hasWhatsApp() ? `+${contact.whatsappNumber.replace(/\D/g, "")}` : "",
      href: whatsappLink(),
      icon: (
        <svg viewBox="0 0 24 24" className={iconCls} fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
          <path d="M4 20l1.3-3.9A8 8 0 1 1 8.3 19L4 20Z" />
          <path d="M9.5 9.5c0 3 2 5 5 5l1-1.5-1.8-.8-.8.8c-1-.3-1.8-1.1-2.1-2.1l.8-.8-.8-1.8L9.5 9.5Z" />
        </svg>
      ),
    },
    {
      key: "email",
      label: "Email",
      configured: hasEmail(),
      value: contact.email,
      href: emailLink(),
      icon: (
        <svg viewBox="0 0 24 24" className={iconCls} fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
          <rect x="3" y="5" width="18" height="14" rx="2" />
          <path d="m3 7 9 6 9-6" />
        </svg>
      ),
    },
    {
      key: "instagram",
      label: "Instagram",
      configured: hasInstagram(),
      value: hasInstagram() ? `@${contact.instagram.replace(/^@/, "")}` : "",
      href: instagramLink(),
      icon: (
        <svg viewBox="0 0 24 24" className={iconCls} fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
          <rect x="3" y="3" width="18" height="18" rx="5" />
          <circle cx="12" cy="12" r="4" />
          <circle cx="17.5" cy="6.5" r="0.8" fill="currentColor" />
        </svg>
      ),
    },
  ];
}

const fieldCls =
  "peer w-full border-b border-white/15 bg-transparent px-0 py-3.5 text-base text-frost outline-none transition-colors duration-300 placeholder:text-transparent focus:border-electric";
const labelCls =
  "pointer-events-none absolute left-0 top-3.5 font-mono text-[0.62rem] uppercase tracking-[0.28em] text-fog transition-all duration-300 peer-focus:-top-3 peer-focus:text-[0.55rem] peer-focus:text-electric peer-[:not(:placeholder-shown)]:-top-3 peer-[:not(:placeholder-shown)]:text-[0.55rem]";

export function Contact() {
  const channels = useChannels();
  const [status, setStatus] = useState<{ type: "idle" | "ok" | "info" | "error"; msg: string }>({
    type: "idle",
    msg: "",
  });

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const name = String(fd.get("name") ?? "").trim();
    const business = String(fd.get("business") ?? "").trim();
    const email = String(fd.get("email") ?? "").trim();
    const need = String(fd.get("need") ?? "").trim();

    if (!name || !email || !need) {
      setStatus({ type: "error", msg: "Please add your name, email and what you need." });
      return;
    }

    const subject = `Website enquiry — ${business || name}`;
    const body = `Name: ${name}\nBusiness: ${business || "—"}\nEmail: ${email}\n\nWhat I need:\n${need}`;

    if (hasEmail()) {
      window.location.href = emailLink(subject, body);
      setStatus({ type: "ok", msg: "Opening your email app with the enquiry pre-filled." });
      return;
    }
    if (hasWhatsApp()) {
      window.open(whatsappLink(body), "_blank", "noopener,noreferrer");
      setStatus({ type: "ok", msg: "Opening WhatsApp with your enquiry pre-filled." });
      return;
    }
    setStatus({
      type: "info",
      msg: "Direct sending isn't connected yet — add an email or WhatsApp number in src/config/site.ts to activate this form.",
    });
  };

  return (
    <section id="contact" aria-labelledby="contact-title" className="relative overflow-hidden py-28 md:py-40">
      <div className="mx-auto max-w-[1440px] px-5 sm:px-8">
        <div className="mb-16 md:mb-20">
          <SectionLabel index="05" className="mb-8">
            Contact
          </SectionLabel>
          <RevealLines
            id="contact-title"
            as="h2"
            className="display text-[clamp(2.6rem,5.6vw,6rem)] text-frost"
            lines={["Let's build", <span className="text-metal">your website.</span>]}
            fit={{ longest: "let's build", max: 128 }}
          />
        </div>

        <div className="grid gap-16 lg:grid-cols-12 lg:gap-10">
          {/* Left: intro + channels */}
          <div className="lg:col-span-5">
            <Reveal delay={0.1}>
              <p className="max-w-md text-base leading-relaxed text-fog sm:text-lg">
                Share a few details about your business and I'll get back to you with next steps.
              </p>
            </Reveal>

            <ul className="mt-10 space-y-3" aria-label="Contact channels">
              {channels.map((c, i) => (
                <motion.li
                  key={c.key}
                  initial={{ opacity: 0, x: -24 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, amount: 0.6 }}
                  transition={{ duration: 0.8, delay: 0.1 + i * 0.08, ease: [0.16, 1, 0.3, 1] }}
                >
                  <a
                    href={c.href}
                    {...(c.configured && c.key !== "email" ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                    className="glass metal-edge group flex items-center gap-5 rounded-[6px] px-5 py-4 transition-colors duration-500 hover:border-white/25"
                    title={c.configured ? undefined : `${c.label} not configured yet — set it in src/config/site.ts`}
                  >
                    <span className="flex h-11 w-11 items-center justify-center rounded-[4px] border border-white/10 bg-white/[0.04] text-frost transition-colors duration-500 group-hover:border-electric/50 group-hover:text-electric">
                      {c.icon}
                    </span>
                    <span className="flex min-w-0 flex-1 flex-col">
                      <span className="font-mono text-[0.62rem] uppercase tracking-[0.3em] text-fog">{c.label}</span>
                      {c.configured ? (
                        <span className="truncate text-base text-frost">{c.value}</span>
                      ) : (
                        <span className="font-mono text-[0.6rem] uppercase tracking-[0.2em] text-fog/60">
                          Set in src/config/site.ts
                        </span>
                      )}
                    </span>
                    <svg
                      aria-hidden="true"
                      viewBox="0 0 24 24"
                      className="h-4 w-4 text-fog transition-transform duration-500 ease-out-expo group-hover:translate-x-1 group-hover:text-frost"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.8"
                    >
                      <path d="M7 17 17 7M9 7h8v8" />
                    </svg>
                  </a>
                </motion.li>
              ))}
            </ul>
          </div>

          {/* Right: form */}
          <div className="lg:col-span-6 lg:col-start-7">
            <Reveal delay={0.15}>
              <TiltCard maxTilt={3} lift={8} glare={false} innerClassName="rounded-[10px]">
                <form
                  onSubmit={onSubmit}
                  noValidate
                  className="glass-strong metal-edge relative rounded-[10px] p-7 sm:p-10"
                  aria-describedby="form-status"
                >
                  <div className="mb-10 flex items-center justify-between">
                    <span className="eyebrow">Project enquiry</span>
                    <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-electric shadow-[0_0_12px_#5b8cff]" />
                  </div>

                  <div className="grid gap-8 sm:grid-cols-2">
                    <div className="relative">
                      <input id="f-name" name="name" type="text" autoComplete="name" required placeholder="Name" className={fieldCls} />
                      <label htmlFor="f-name" className={labelCls}>
                        Name
                      </label>
                    </div>
                    <div className="relative">
                      <input id="f-business" name="business" type="text" autoComplete="organization" placeholder="Business name" className={fieldCls} />
                      <label htmlFor="f-business" className={labelCls}>
                        Business name
                      </label>
                    </div>
                    <div className="relative sm:col-span-2">
                      <input id="f-email" name="email" type="email" autoComplete="email" required placeholder="Email" className={fieldCls} />
                      <label htmlFor="f-email" className={labelCls}>
                        Email
                      </label>
                    </div>
                    <div className="relative sm:col-span-2">
                      <textarea id="f-need" name="need" rows={4} required placeholder="What do you need?" className={cn(fieldCls, "resize-none")} />
                      <label htmlFor="f-need" className={labelCls}>
                        What do you need?
                      </label>
                    </div>
                  </div>

                  <div className="mt-10 flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
                    <Button type="submit" variant="primary">
                      Send enquiry
                    </Button>
                    <p className="font-mono text-[0.6rem] uppercase tracking-[0.22em] text-fog/70">Details are only used to reply to you</p>
                  </div>

                  <p
                    id="form-status"
                    role="status"
                    aria-live="polite"
                    className={cn(
                      "mt-6 min-h-[1.25rem] text-sm leading-relaxed transition-opacity",
                      status.type === "error" && "text-[#ff8a8a]",
                      status.type === "ok" && "text-electric",
                      status.type === "info" && "text-fog",
                      status.type === "idle" && "opacity-0",
                    )}
                  >
                    {status.msg || "\u00A0"}
                  </p>
                </form>
              </TiltCard>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
