import { useRef, type ReactNode } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { usePointer } from "@/context/PointerContext";
import { useIsDesktop } from "@/hooks/useMediaQuery";
import { featuredProject, secondProject, upcomingSlots, type Project } from "@/config/site";
import { BrowserWindow, EmptySlot } from "@/components/ui/BrowserWindow";
import { PhoneMockup } from "@/components/ui/PhoneMockup";
import { LiveFrame } from "@/components/ui/LiveFrame";
import { ButtonLink } from "@/components/ui/Button";
import { TiltCard } from "@/components/ui/TiltCard";
import { FloatChip, SectionLabel } from "@/components/ui/SectionLabel";
import { Reveal, RevealLines } from "@/components/ui/Reveal";
import { cn } from "@/utils/cn";

function Orbit({
  children,
  depth,
  className,
  parallax = 1,
  delay = 0,
}: {
  children: ReactNode;
  depth: number;
  className?: string;
  parallax?: number;
  delay?: number;
}) {
  const { px, py } = usePointer();
  const x = useTransform(px, [-1, 1], [-16 * parallax, 16 * parallax]);
  const y = useTransform(py, [-1, 1], [-12 * parallax, 12 * parallax]);
  return (
    <motion.div
      className={cn("absolute z-20", className)}
      style={{ x, y, z: depth, transformStyle: "preserve-3d" }}
      initial={{ opacity: 0, scale: 0.8 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, amount: 0.5 }}
      transition={{ duration: 0.8, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      <div className="animate-float" style={{ animationDelay: `${delay * 3}s` }}>
        {children}
      </div>
    </motion.div>
  );
}

function CaseStudy({
  project,
  reverse = false,
  featured = false,
}: {
  project: Project;
  reverse?: boolean;
  featured?: boolean;
}) {
  const ref = useRef<HTMLElement>(null);
  const isDesktop = useIsDesktop();
  const { px, py } = usePointer();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });

  const dir = (reverse ? -1 : 1) * (isDesktop ? 1 : 0.45);
  const sRotY = useTransform(scrollYProgress, [0, 0.5, 1], [-12 * dir, -4 * dir, 2 * dir]);
  const sY = useTransform(scrollYProgress, [0, 1], [60, -60]);
  const mRotY = useTransform(px, [-1, 1], [-5, 5]);
  const mRotX = useTransform(py, [-1, 1], [3, -3]);
  const rotateY = useTransform(() => sRotY.get() + mRotY.get());
  const rotateX = useTransform(() => 2 + mRotX.get());
  const phoneY = useTransform(scrollYProgress, [0, 1], [120, -110]);
  const phoneRotY = useTransform(px, [-1, 1], [-4, -14]);
  const numeralY = useTransform(scrollYProgress, [0, 1], [80, -80]);

  const glow = project.id === "ayesha-salon" ? "warm" : "violet";

  return (
    <article
      ref={ref}
      aria-labelledby={`project-${project.id}`}
      className={cn("relative", featured ? "pt-8 md:pt-16" : "pt-32 md:pt-48")}
    >
      {/* Giant numeral */}
      <motion.span
        aria-hidden="true"
        className={cn(
          "display pointer-events-none absolute -top-6 select-none text-[clamp(8rem,26vw,24rem)] leading-none text-outline opacity-60 md:-top-12",
          reverse ? "right-0" : "left-0",
        )}
        style={{ y: numeralY }}
      >
        {project.index}
      </motion.span>

      <div className={cn("relative grid items-center gap-12 lg:grid-cols-12 lg:gap-8", reverse && "lg:[&>*:first-child]:order-2")}>
        {/* Info */}
        <div className={cn("relative z-10 lg:col-span-4", reverse && "lg:col-start-9")}>
          <Reveal>
            <span className="font-mono text-[0.68rem] tracking-[0.3em] text-electric">{project.index}</span>
            <h3
              id={`project-${project.id}`}
              className="display mt-5 text-[clamp(2rem,4vw,3.6rem)] text-frost"
            >
              {project.name}
            </h3>
            <p className="eyebrow mt-4">{project.category}</p>
            <p className="mt-6 max-w-md text-base leading-relaxed text-fog sm:text-lg">{project.description}</p>
            <ul className="mt-8 flex flex-wrap gap-2" aria-label="Project highlights">
              {project.tags.map((t) => (
                <li
                  key={t}
                  className="rounded-[3px] border border-white/10 bg-white/[0.03] px-3 py-1.5 font-mono text-[0.6rem] uppercase tracking-[0.25em] text-fog"
                >
                  {t}
                </li>
              ))}
            </ul>
            <div className="mt-10">
              <ButtonLink href={project.url} variant="primary" aria-label={`View live project: ${project.name} (opens in a new tab)`}>
                View live project
              </ButtonLink>
            </div>
          </Reveal>
        </div>

        {/* 3D stage */}
        <div className={cn("perspective-far relative lg:col-span-8", reverse ? "lg:col-start-1 lg:pr-10" : "lg:pl-10")}>
          <a
            href={project.url}
            target="_blank"
            rel="noopener noreferrer"
            data-cursor="view"
            aria-label={`Open ${project.name} live website in a new tab`}
            className="group/stage block rounded-[12px] outline-offset-8"
          >
            <BrowserWindow
              url={project.url}
              depth={24}
              glow={glow}
              style={{ rotateY, rotateX, y: sY, transformOrigin: "50% 50%" }}
              float={
                featured ? (
                  <>
                    <Orbit depth={120} parallax={1.4} delay={0.1} className="left-[2%] top-[10%] lg:left-[-9%]">
                      <FloatChip>Salon</FloatChip>
                    </Orbit>
                    <Orbit depth={160} parallax={1.9} delay={0.25} className="right-[2%] top-[24%] lg:right-[-1%]">
                      <FloatChip dot="bg-violet">Academy</FloatChip>
                    </Orbit>
                    <Orbit depth={90} parallax={1.1} delay={0.4} className="left-[6%] bottom-[-4%] lg:left-[4%]">
                      <FloatChip dot="bg-white">Courses</FloatChip>
                    </Orbit>
                    <Orbit depth={140} parallax={1.6} delay={0.55} className="left-[30%] top-[-5%] lg:left-[36%]">
                      <FloatChip>Student Experience</FloatChip>
                    </Orbit>
                  </>
                ) : (
                  <>
                    {project.tags.slice(0, 2).map((t, i) => (
                      <Orbit
                        key={t}
                        depth={110 + i * 40}
                        parallax={1.3 + i * 0.4}
                        delay={0.1 + i * 0.15}
                        className={i === 0 ? "right-[2%] top-[12%] lg:right-[-1%]" : "left-[8%] bottom-[-4%]"}
                      >
                        <FloatChip dot={i === 0 ? "bg-violet" : "bg-white"}>{t}</FloatChip>
                      </Orbit>
                    ))}
                  </>
                )
              }
            >
              <LiveFrame url={project.url} name={project.name} palette={project.palette} />
            </BrowserWindow>
          </a>

          {/* Mobile view of the same live project (desktop only, lazily mounted) */}
          {featured && isDesktop && (
            <PhoneMockup
              width={190}
              className="absolute bottom-[-10%] right-[3%] z-30"
              style={{ y: phoneY, rotateY: phoneRotY, rotateX: 4, z: 140 }}
            >
              <LiveFrame
                url={project.url}
                name={project.name}
                palette={project.palette}
                viewportWidth={390}
                aspect={390 / 844}
                delay={600}
              />
            </PhoneMockup>
          )}
        </div>
      </div>
    </article>
  );
}

function SlotCard({ label, i }: { label: string; i: number }) {
  return (
    <motion.li
      className="list-none"
      initial={{ opacity: 0, y: 60, rotateY: i === 0 ? -14 : 14 }}
      whileInView={{ opacity: 1, y: 0, rotateY: i === 0 ? -6 : 6 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 1.1, delay: i * 0.15, ease: [0.16, 1, 0.3, 1] }}
      style={{ transformStyle: "preserve-3d" }}
    >
      <TiltCard maxTilt={5} lift={10} glare={false}>
        <BrowserWindow depth={14} glow="none" compact>
          <EmptySlot label={label} />
        </BrowserWindow>
      </TiltCard>
    </motion.li>
  );
}

export function Work() {
  return (
    <section id="work" aria-labelledby="work-title" className="relative overflow-hidden py-28 md:py-40">
      <div className="mx-auto max-w-[1440px] px-5 sm:px-8">
        <div className="mb-20 md:mb-28">
          <SectionLabel index="02" className="mb-8">
            Portfolio
          </SectionLabel>
          <RevealLines
            id="work-title"
            as="h2"
            className="display text-[clamp(2.6rem,7vw,7.6rem)] text-frost"
            lines={["Selected", <span className="text-metal">work</span>]}
          />
        </div>

        <CaseStudy project={featuredProject} featured />
        <CaseStudy project={secondProject} reverse />

        {/* Ready-to-replace slots */}
        <div className="mt-36 md:mt-48">
          <Reveal>
            <div className="mb-10 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-4">
                <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-electric" />
                <span className="eyebrow text-frost">More projects coming soon</span>
              </div>
              <p className="max-w-xs text-sm text-fog/80 sm:text-right">Slots reserved for the next websites launching.</p>
            </div>
          </Reveal>
          <ul className="perspective-far grid gap-6 md:grid-cols-2 md:gap-8" role="list">
            {upcomingSlots.map((label, i) => (
              <SlotCard key={label} label={label} i={i} />
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
