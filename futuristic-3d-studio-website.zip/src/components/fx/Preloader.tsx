import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";

const KEY = "sds:intro-seen";

/**
 * Short "studio entrance" — brand mark + progress line, then the curtain lifts.
 * Shown once per session, skipped entirely for reduced-motion users.
 */
export function Preloader({ onDone }: { onDone: () => void }) {
  const reduced = useReducedMotion();
  const [show, setShow] = useState(() => {
    if (typeof window === "undefined") return false;
    try {
      return !reduced && sessionStorage.getItem(KEY) !== "1";
    } catch {
      return !reduced;
    }
  });

  useEffect(() => {
    if (!show) {
      onDone();
      return;
    }
    document.documentElement.style.overflow = "hidden";
    const t = window.setTimeout(() => {
      try {
        sessionStorage.setItem(KEY, "1");
      } catch {
        /* private mode */
      }
      setShow(false);
    }, 1500);
    return () => {
      window.clearTimeout(t);
      document.documentElement.style.overflow = "";
    };
  }, [show, onDone]);

  return (
    <AnimatePresence
      onExitComplete={() => {
        document.documentElement.style.overflow = "";
        onDone();
      }}
    >
      {show && (
        <motion.div
          key="preloader"
          aria-hidden="true"
          className="fixed inset-0 z-[90] flex flex-col items-center justify-center bg-ink"
          initial={{ clipPath: "inset(0 0 0% 0)" }}
          exit={{ clipPath: "inset(0 0 100% 0)" }}
          transition={{ duration: 0.9, ease: [0.76, 0, 0.24, 1] }}
        >
          <motion.div
            className="flex flex-col items-center"
            exit={{ opacity: 0, y: -30 }}
            transition={{ duration: 0.35 }}
          >
            <div className="flex gap-[0.35em] overflow-hidden font-display text-[clamp(1.4rem,4vw,2.6rem)] font-extrabold uppercase tracking-[-0.02em]">
              {["SAMIYA", "DIGITAL", "STUDIO"].map((word, i) => (
                <motion.span
                  key={word}
                  className={i === 2 ? "text-electric-gradient" : "text-frost"}
                  initial={{ y: "110%" }}
                  animate={{ y: 0 }}
                  transition={{ duration: 0.8, delay: 0.1 + i * 0.08, ease: [0.16, 1, 0.3, 1] }}
                >
                  {word}
                </motion.span>
              ))}
            </div>
            <div className="mt-6 h-px w-40 overflow-hidden bg-white/10">
              <motion.div
                className="h-full bg-gradient-to-r from-electric to-violet"
                initial={{ scaleX: 0, originX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 1.2, ease: [0.65, 0, 0.35, 1] }}
              />
            </div>
            <p className="eyebrow mt-4 text-[0.6rem]">Website Designer &amp; Developer</p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
