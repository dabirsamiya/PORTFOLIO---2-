import { useEffect, useRef } from "react";
import { useReducedMotion } from "framer-motion";
import { useIsTouch } from "@/hooks/useMediaQuery";

type P = { x: number; y: number; z: number; vx: number; vy: number; hue: number; tw: number };

/**
 * Lightweight depth-sorted particle field (Canvas 2D).
 * ~90 particles on desktop, ~36 on touch devices. Pauses when the tab is hidden.
 */
export function ParticleField() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const reduced = useReducedMotion();
  const isTouch = useIsTouch();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    let raf = 0;
    let w = 0;
    let h = 0;
    let dpr = 1;
    let particles: P[] = [];
    let running = true;
    const mouse = { x: 0.5, y: 0.5, tx: 0.5, ty: 0.5 };

    const count = () => (isTouch ? 36 : Math.min(110, Math.round((window.innerWidth * window.innerHeight) / 16000)));

    const seed = () => {
      particles = Array.from({ length: count() }, () => {
        const z = 0.15 + Math.random() ** 1.6 * 0.85;
        return {
          x: Math.random() * w,
          y: Math.random() * h,
          z,
          vx: (Math.random() - 0.5) * 0.12 * z,
          vy: -(0.04 + Math.random() * 0.1) * z,
          hue: Math.random() < 0.7 ? 220 : Math.random() < 0.5 ? 258 : 0,
          tw: Math.random() * Math.PI * 2,
        };
      });
    };

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      seed();
      if (reduced) draw(0);
    };

    const draw = (t: number) => {
      ctx.clearRect(0, 0, w, h);
      mouse.x += (mouse.tx - mouse.x) * 0.04;
      mouse.y += (mouse.ty - mouse.y) * 0.04;
      const ox = (mouse.x - 0.5) * 40;
      const oy = (mouse.y - 0.5) * 40;

      for (const p of particles) {
        if (!reduced) {
          p.x += p.vx;
          p.y += p.vy;
          if (p.y < -10) {
            p.y = h + 10;
            p.x = Math.random() * w;
          }
          if (p.x < -10) p.x = w + 10;
          if (p.x > w + 10) p.x = -10;
        }
        const twinkle = 0.65 + 0.35 * Math.sin(t * 0.0012 + p.tw);
        const r = 0.6 + p.z * 1.7;
        const a = (0.08 + p.z * 0.5) * twinkle;
        const x = p.x - ox * p.z;
        const y = p.y - oy * p.z;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fillStyle =
          p.hue === 0 ? `rgba(255,255,255,${a})` : `hsla(${p.hue}, 100%, ${p.hue === 220 ? 78 : 80}%, ${a})`;
        ctx.fill();
        if (p.z > 0.85) {
          ctx.beginPath();
          ctx.arc(x, y, r * 3.2, 0, Math.PI * 2);
          ctx.fillStyle = `hsla(${p.hue || 220}, 100%, 80%, ${a * 0.12})`;
          ctx.fill();
        }
      }
    };

    const loop = (t: number) => {
      if (!running) return;
      draw(t);
      raf = requestAnimationFrame(loop);
    };

    const onMove = (e: PointerEvent) => {
      mouse.tx = e.clientX / w;
      mouse.ty = e.clientY / h;
    };
    const onVis = () => {
      running = !document.hidden && !reduced;
      cancelAnimationFrame(raf);
      if (running) raf = requestAnimationFrame(loop);
    };

    resize();
    window.addEventListener("resize", resize);
    document.addEventListener("visibilitychange", onVis);
    if (!isTouch) window.addEventListener("pointermove", onMove, { passive: true });
    if (!reduced) raf = requestAnimationFrame(loop);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("pointermove", onMove);
    };
  }, [reduced, isTouch]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-[1] h-dvh w-full"
    />
  );
}
