import { cn } from "@/utils/cn";

/* ───────────── Glass cube ───────────── */
export function Cube3D({
  size = 72,
  className,
  active = false,
  label,
}: {
  size?: number;
  className?: string;
  active?: boolean;
  label?: string;
}) {
  const half = size / 2;
  const faces = [
    `rotateY(0deg) translateZ(${half}px)`,
    `rotateY(90deg) translateZ(${half}px)`,
    `rotateY(180deg) translateZ(${half}px)`,
    `rotateY(-90deg) translateZ(${half}px)`,
    `rotateX(90deg) translateZ(${half}px)`,
    `rotateX(-90deg) translateZ(${half}px)`,
  ];
  return (
    <div
      aria-hidden="true"
      className={cn("perspective-near relative", className)}
      style={{ width: size, height: size }}
    >
      <div className="preserve-3d absolute inset-0">
        {/* Glow sits behind the object (no CSS filter — filters flatten 3D contexts) */}
        <div
          className={cn(
            "absolute -inset-6 rounded-full transition-opacity duration-700",
            active ? "opacity-100" : "opacity-0",
          )}
          style={{
            transform: `translateZ(-${half + 10}px)`,
            background: "radial-gradient(circle, rgba(91,140,255,0.45), transparent 65%)",
          }}
        />
        <div className="preserve-3d animate-cube absolute inset-0">
          {faces.map((t, i) => (
            <div
              key={i}
              className={cn(
                "absolute inset-0 border transition-colors duration-700",
                active ? "border-electric/70 bg-electric/[0.08]" : "border-white/20 bg-white/[0.03]",
              )}
              style={{
                transform: t,
                boxShadow: active
                  ? "inset 0 0 24px rgba(91,140,255,0.18)"
                  : "inset 0 0 24px rgba(255,255,255,0.05)",
              }}
            />
          ))}
        </div>
        {label && (
          <div
            className={cn(
              "absolute inset-0 flex items-center justify-center font-mono text-xs tracking-[0.2em] transition-colors duration-700",
              active ? "text-white" : "text-frost/80",
            )}
            style={{ transform: `translateZ(${half + 16}px)` }}
          >
            {label}
          </div>
        )}
      </div>
    </div>
  );
}

/* ───────────── Gyroscope rings ───────────── */
export function Gyro({ size = 160, className }: { size?: number; className?: string }) {
  return (
    <div
      aria-hidden="true"
      className={cn("perspective-near relative", className)}
      style={{ width: size, height: size }}
    >
      <div className="preserve-3d absolute inset-0" style={{ transform: "rotateX(62deg) rotateZ(-18deg)" }}>
        <div className="absolute inset-0 animate-spin-slow rounded-full border border-white/25 [box-shadow:0_0_30px_rgba(91,140,255,0.12)_inset]" />
        <div
          className="absolute inset-[12%] animate-spin-slower rounded-full border border-electric/50"
          style={{ transform: "rotateX(70deg)" }}
        />
        <div
          className="absolute inset-[26%] animate-spin-slow rounded-full border border-violet/50 [animation-direction:reverse]"
          style={{ transform: "rotateY(70deg)" }}
        />
        <div className="absolute inset-[42%] rounded-full bg-[radial-gradient(circle,rgba(255,255,255,0.95),rgba(91,140,255,0.6)_45%,transparent_70%)]" />
      </div>
    </div>
  );
}

/* ───────────── Stacked glass layers ───────────── */
export function Layers3D({ className, width = 150 }: { className?: string; width?: number }) {
  const height = width * 0.64;
  return (
    <div
      aria-hidden="true"
      className={cn("perspective-near relative", className)}
      style={{ width, height: height + 60 }}
    >
      <div className="preserve-3d absolute inset-x-0 top-6 animate-float-slow" style={{ height }}>
        <div className="preserve-3d absolute inset-0" style={{ transform: "rotateX(58deg) rotateZ(-32deg)" }}>
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className={cn(
              "absolute inset-0 rounded-[3px] border",
              i === 0 && "border-white/15 bg-white/[0.03]",
              i === 1 && "border-electric/40 bg-electric/[0.08]",
              i === 2 && "border-white/35 bg-white/[0.06]",
            )}
            style={{ transform: `translateZ(${i * 26}px)`, backdropFilter: "blur(2px)" }}
          >
            {i === 2 && (
              <>
                <div className="absolute left-3 top-3 h-1 w-1/3 rounded-full bg-white/50" />
                <div className="absolute left-3 top-6 h-1 w-1/2 rounded-full bg-white/25" />
                <div className="absolute bottom-3 left-3 h-3 w-10 rounded-sm bg-electric/70" />
              </>
            )}
          </div>
        ))}
        </div>
      </div>
    </div>
  );
}

/* ───────────── Wireframe ring (for depth-of-field background bits) ───────────── */
export function Ring({ size = 220, className, blur = 0 }: { size?: number; className?: string; blur?: number }) {
  return (
    <div
      aria-hidden="true"
      className={cn("pointer-events-none absolute rounded-full border border-white/10", className)}
      style={{
        width: size,
        height: size,
        transform: "rotateX(70deg)",
        filter: blur ? `blur(${blur}px)` : undefined,
        boxShadow: "0 0 40px rgba(91,140,255,0.08) inset",
      }}
    />
  );
}
