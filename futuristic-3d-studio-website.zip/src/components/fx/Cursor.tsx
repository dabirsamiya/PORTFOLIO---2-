import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring, useReducedMotion } from "framer-motion";
import { useIsTouch } from "@/hooks/useMediaQuery";

/**
 * Minimal premium cursor: a crisp dot + a lagging ring.
 * Ring expands over interactive elements; shows a label for `data-cursor="view"`.
 * Only active on fine pointers without reduced-motion preference.
 */
export function Cursor() {
  const isTouch = useIsTouch();
  const reduced = useReducedMotion();
  const enabled = !isTouch && !reduced;

  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const rx = useSpring(x, { stiffness: 320, damping: 30, mass: 0.5 });
  const ry = useSpring(y, { stiffness: 320, damping: 30, mass: 0.5 });
  const [mode, setMode] = useState<"default" | "link" | "view" | "hidden" | "text">("default");

  useEffect(() => {
    if (!enabled) {
      document.body.classList.remove("has-cursor");
      return;
    }
    document.body.classList.add("has-cursor");

    const onMove = (e: PointerEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
    };
    const onOver = (e: PointerEvent) => {
      const el = e.target as HTMLElement | null;
      if (!el || !(el instanceof Element)) return;
      if (el.closest("input, textarea, select")) return setMode("text");
      const view = el.closest("[data-cursor='view']");
      if (view) return setMode("view");
      if (el.closest("a, button, [role='button'], label")) return setMode("link");
      setMode("default");
    };
    const onLeave = () => setMode("hidden");
    const onEnter = () => setMode("default");

    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerover", onOver, { passive: true });
    document.documentElement.addEventListener("pointerleave", onLeave);
    document.documentElement.addEventListener("pointerenter", onEnter);
    return () => {
      document.body.classList.remove("has-cursor");
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerover", onOver);
      document.documentElement.removeEventListener("pointerleave", onLeave);
      document.documentElement.removeEventListener("pointerenter", onEnter);
    };
  }, [enabled, x, y]);

  if (!enabled) return null;

  const ringSize = mode === "view" ? 84 : mode === "link" ? 52 : 34;
  const hidden = mode === "hidden" || mode === "text";

  return (
    <>
      <motion.div
        aria-hidden="true"
        className="pointer-events-none fixed left-0 top-0 z-[100] h-1.5 w-1.5 rounded-full bg-white"
        style={{ x, y, translateX: "-50%", translateY: "-50%", opacity: hidden || mode === "view" ? 0 : 1 }}
      />
      <motion.div
        aria-hidden="true"
        className="pointer-events-none fixed left-0 top-0 z-[100] flex items-center justify-center rounded-full border border-white/70 mix-blend-difference"
        style={{ x: rx, y: ry, translateX: "-50%", translateY: "-50%" }}
        animate={{
          width: ringSize,
          height: ringSize,
          opacity: hidden ? 0 : 1,
          backgroundColor: mode === "view" ? "rgba(255,255,255,0.92)" : "rgba(255,255,255,0)",
        }}
        transition={{ type: "spring", stiffness: 260, damping: 26 }}
      >
        <span
          className="font-mono text-[10px] tracking-[0.25em] text-black transition-opacity duration-200"
          style={{ opacity: mode === "view" ? 1 : 0 }}
        >
          VIEW
        </span>
      </motion.div>
    </>
  );
}
