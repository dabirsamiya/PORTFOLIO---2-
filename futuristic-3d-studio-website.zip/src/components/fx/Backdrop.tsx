import { motion, useTransform } from "framer-motion";
import { usePointer } from "@/context/PointerContext";

/**
 * Fixed atmospheric backdrop: deep gradient base, two soft light sources that
 * drift with the pointer (radial gradients — no expensive blur filters), and a
 * fine grain overlay for a premium finish.
 */
export function Backdrop() {
  const { px, py } = usePointer();
  const gx1 = useTransform(px, [-1, 1], [-60, 60]);
  const gy1 = useTransform(py, [-1, 1], [-40, 40]);
  const gx2 = useTransform(px, [-1, 1], [50, -50]);
  const gy2 = useTransform(py, [-1, 1], [30, -30]);

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(120%_80%_at_50%_-10%,#141a2e_0%,#07080c_55%)]" />
      <motion.div
        className="absolute -left-[20vw] top-[-10vh] h-[70vh] w-[70vw] rounded-full opacity-70"
        style={{
          x: gx1,
          y: gy1,
          background: "radial-gradient(closest-side, rgba(91,140,255,0.16), rgba(91,140,255,0.04) 55%, transparent 72%)",
        }}
      />
      <motion.div
        className="absolute -right-[15vw] top-[25vh] h-[70vh] w-[60vw] rounded-full opacity-70"
        style={{
          x: gx2,
          y: gy2,
          background: "radial-gradient(closest-side, rgba(139,108,255,0.14), rgba(139,108,255,0.03) 55%, transparent 72%)",
        }}
      />
      <div className="noise absolute inset-0 opacity-[0.05]" />
    </div>
  );
}
