import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from "framer-motion";
import { siteConfig } from "@/config/site";
import { ButtonLink } from "@/components/ui/Button";
import { cn } from "@/utils/cn";

export function Navbar() {
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);
  const { scrollY } = useScroll();
  const firstLinkRef = useRef<HTMLAnchorElement>(null);
  const toggleRef = useRef<HTMLButtonElement>(null);

  useMotionValueEvent(scrollY, "change", (v) => setSolid(v > 24));

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const t = window.setTimeout(() => firstLinkRef.current?.focus(), 350);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        toggleRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.clearTimeout(t);
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  useEffect(() => {
    const onResize = () => window.innerWidth >= 1024 && setOpen(false);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[80] focus:rounded-sm focus:bg-white focus:px-4 focus:py-2 focus:font-mono focus:text-xs focus:tracking-widest focus:text-ink"
      >
        Skip to content
      </a>

      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
        className="fixed inset-x-0 top-0 z-[70] px-4 pt-4 sm:px-6 lg:px-8"
      >
        <nav
          aria-label="Primary"
          className={cn(
            "mx-auto flex h-14 max-w-[1440px] items-center justify-between rounded-[6px] border px-4 transition-[background-color,border-color,backdrop-filter,box-shadow] duration-500 sm:px-5",
            solid || open
              ? "border-white/10 bg-ink/70 shadow-[0_20px_50px_-30px_rgba(0,0,0,0.9)] backdrop-blur-xl"
              : "border-transparent bg-transparent",
          )}
        >
          <a
            href="#top"
            className="group flex items-center gap-3 font-display text-[0.8rem] font-extrabold uppercase tracking-[0.12em] text-frost"
            aria-label={`${siteConfig.name} — back to top`}
          >
            <span className="relative flex h-6 w-6 items-center justify-center">
              <span className="absolute inset-0 rounded-[4px] border border-white/20 transition-transform duration-500 group-hover:rotate-45" />
              <span className="h-1.5 w-1.5 rounded-full bg-electric shadow-[0_0_12px_#5b8cff]" />
            </span>
            <span className="hidden sm:inline">{siteConfig.name}</span>
            <span className="sm:hidden">{siteConfig.shortName}</span>
          </a>

          <ul className="hidden items-center gap-8 lg:flex">
            {siteConfig.nav.map((item) => (
              <li key={item.href}>
                <a
                  href={item.href}
                  className="group relative font-mono text-[0.66rem] uppercase tracking-[0.28em] text-fog transition-colors hover:text-frost"
                >
                  {item.label}
                  <span className="absolute -bottom-1.5 left-0 h-px w-full origin-left scale-x-0 bg-electric transition-transform duration-500 ease-out-expo group-hover:scale-x-100" />
                </a>
              </li>
            ))}
          </ul>

          <div className="hidden lg:block">
            <ButtonLink href="#contact" variant="outline" className="px-5 py-2.5 text-[0.62rem]">
              Start a project
            </ButtonLink>
          </div>

          <button
            ref={toggleRef}
            type="button"
            className="relative flex h-10 w-10 items-center justify-center lg:hidden"
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
          >
            <span
              className={cn(
                "absolute h-px w-6 bg-frost transition-all duration-500 ease-out-expo",
                open ? "rotate-45" : "-translate-y-[5px]",
              )}
            />
            <span
              className={cn(
                "absolute h-px w-6 bg-frost transition-all duration-500 ease-out-expo",
                open ? "-rotate-45" : "translate-y-[5px]",
              )}
            />
          </button>
        </nav>
      </motion.header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            role="dialog"
            aria-modal="true"
            aria-label="Menu"
            className="fixed inset-0 z-[60] flex flex-col bg-ink/95 px-6 pb-10 pt-28 backdrop-blur-2xl lg:hidden"
            initial={{ opacity: 0, clipPath: "inset(0 0 100% 0)" }}
            animate={{ opacity: 1, clipPath: "inset(0 0 0% 0)" }}
            exit={{ opacity: 0, clipPath: "inset(0 0 100% 0)" }}
            transition={{ duration: 0.6, ease: [0.76, 0, 0.24, 1] }}
          >
            <ul className="flex flex-col gap-2">
              {siteConfig.nav.map((item, i) => (
                <li key={item.href} className="overflow-hidden">
                  <motion.a
                    ref={i === 0 ? firstLinkRef : undefined}
                    href={item.href}
                    onClick={() => setOpen(false)}
                    className="flex items-baseline gap-4 py-3 font-display text-[2.6rem] font-extrabold uppercase leading-none tracking-tight text-frost"
                    initial={{ y: "110%" }}
                    animate={{ y: 0 }}
                    exit={{ y: "110%", transition: { duration: 0.3, delay: 0 } }}
                    transition={{ duration: 0.7, delay: 0.1 + i * 0.06, ease: [0.16, 1, 0.3, 1] }}
                  >
                    <span className="font-mono text-[0.62rem] tracking-[0.3em] text-electric">0{i + 1}</span>
                    {item.label}
                  </motion.a>
                </li>
              ))}
            </ul>
            <motion.div
              className="mt-auto flex flex-col gap-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ delay: 0.45 }}
            >
              <p className="eyebrow">{siteConfig.role}</p>
              <ButtonLink href="#contact" onClick={() => setOpen(false)} className="w-full">
                Build my website
              </ButtonLink>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
