import { motion } from "framer-motion";
import { siteConfig } from "@/config/site";

export function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-white/[0.06] pt-20">
      <div className="relative z-10 mx-auto max-w-[1440px] px-5 sm:px-8">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr] lg:grid-cols-[1.6fr_1fr_1fr]">
          <div>
            <a href="#top" className="font-display text-lg font-extrabold uppercase tracking-[0.08em] text-frost">
              {siteConfig.name}
            </a>
            <p className="mt-5 max-w-sm font-display text-xl font-bold uppercase leading-tight tracking-tight text-fog sm:text-2xl">
              Websites for businesses that want to be remembered.
            </p>
          </div>

          <nav aria-label="Footer">
            <p className="eyebrow mb-6">Navigate</p>
            <ul className="space-y-3">
              {siteConfig.footerNav.map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    className="group inline-flex items-center gap-3 font-mono text-[0.7rem] uppercase tracking-[0.28em] text-frost/80 transition-colors hover:text-white"
                  >
                    <span className="h-px w-4 bg-electric/70 transition-all duration-500 group-hover:w-8" />
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <p className="eyebrow mb-6">Studio</p>
            <p className="text-sm leading-relaxed text-fog">
              {siteConfig.role}
              <br />
              {siteConfig.positioning}
            </p>
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-4 border-t border-white/[0.06] py-8 font-mono text-[0.62rem] uppercase tracking-[0.25em] text-fog/80 sm:flex-row sm:items-center sm:justify-between">
          <p>© {siteConfig.year} Samiya Digital Studio. All rights reserved.</p>
          <a href="#top" className="inline-flex items-center gap-2 transition-colors hover:text-frost">
            Back to top
            <svg aria-hidden="true" viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 19V5M6 11l6-6 6 6" />
            </svg>
          </a>
        </div>
      </div>

      {/* Massive 3D wordmark */}
      <div aria-hidden="true" className="perspective-mid pointer-events-none relative z-0 -mb-[1.5vw] select-none overflow-hidden">
        <motion.p
          className="display whitespace-nowrap text-center text-[15.5vw] leading-[0.8] text-outline"
          initial={{ rotateX: 40, opacity: 0 }}
          whileInView={{ rotateX: 18, opacity: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
          style={{ transformOrigin: "50% 100%" }}
        >
          SAMIYA
        </motion.p>
      </div>
    </footer>
  );
}
