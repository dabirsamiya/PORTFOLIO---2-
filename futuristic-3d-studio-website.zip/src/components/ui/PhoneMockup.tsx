import type { ReactNode } from "react";
import { motion, type MotionStyle } from "framer-motion";
import { cn } from "@/utils/cn";

/** Slim metallic phone frame — used to show the responsive/mobile view of a live project. */
export function PhoneMockup({
  children,
  className,
  style,
  width = 200,
}: {
  children: ReactNode;
  className?: string;
  style?: MotionStyle;
  width?: number;
}) {
  return (
    <motion.div
      className={cn("preserve-3d relative will-change-transform", className)}
      style={{ ...style, width }}
    >
      <div
        aria-hidden="true"
        className="absolute inset-0 rounded-[2.2rem] bg-[#1a1e2a]"
        style={{ transform: "translateZ(-10px)", boxShadow: "0 50px 90px -30px rgba(0,0,0,0.9)" }}
      />
      <div
        className="metal-edge relative overflow-hidden rounded-[2.2rem] border border-white/10 bg-ink-2 p-[6px]"
        style={{ boxShadow: "0 30px 70px -20px rgba(0,0,0,0.9), inset 0 1px 0 rgba(255,255,255,0.08)" }}
      >
        <div className="relative isolate aspect-[390/844] w-full overflow-hidden rounded-[1.85rem] bg-ink-3">
          {children}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute left-1/2 top-2 z-20 h-[18px] w-[34%] -translate-x-1/2 rounded-full bg-black"
          />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 z-10 bg-[linear-gradient(115deg,rgba(255,255,255,0.10),transparent_35%)]"
          />
        </div>
      </div>
    </motion.div>
  );
}
