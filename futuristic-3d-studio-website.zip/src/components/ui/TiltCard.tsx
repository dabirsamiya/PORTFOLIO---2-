import { useRef, type ReactNode, type PointerEvent, type CSSProperties } from "react";
import { motion, useMotionValue, useSpring, useReducedMotion } from "framer-motion";
import { useIsTouch } from "@/hooks/useMediaQuery";
import { cn } from "@/utils/cn";

/**
 * 3D tilt surface with a pointer-following light source and specular glare.
 * Children can use `translateZ` (preserve-3d is on) to float above the surface.
 */
export function TiltCard({
  children,
  className,
  innerClassName,
  maxTilt = 9,
  lift = 12,
  glare = true,
  style,
}: {
  children: ReactNode;
  className?: string;
  innerClassName?: string;
  maxTilt?: number;
  lift?: number;
  glare?: boolean;
  style?: CSSProperties;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const isTouch = useIsTouch();
  const reduced = useReducedMotion();
  const enabled = !isTouch && !reduced;

  const rx = useMotionValue(0);
  const ry = useMotionValue(0);
  const z = useMotionValue(0);
  const srx = useSpring(rx, { stiffness: 160, damping: 18, mass: 0.5 });
  const sry = useSpring(ry, { stiffness: 160, damping: 18, mass: 0.5 });
  const sz = useSpring(z, { stiffness: 160, damping: 20 });

  const onMove = (e: PointerEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    el.style.setProperty("--mx", `${px * 100}%`);
    el.style.setProperty("--my", `${py * 100}%`);
    if (!enabled) return;
    rx.set((0.5 - py) * maxTilt * 2);
    ry.set((px - 0.5) * maxTilt * 2);
    z.set(lift);
  };
  const onLeave = () => {
    rx.set(0);
    ry.set(0);
    z.set(0);
  };

  return (
    <div className={cn("perspective-mid", className)} style={style}>
      <motion.div
        ref={ref}
        onPointerMove={onMove}
        onPointerLeave={onLeave}
        className={cn("preserve-3d group/tilt relative h-full will-change-transform", innerClassName)}
        style={{ rotateX: srx, rotateY: sry, z: sz }}
      >
        {children}
        {glare && (
          <span
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 rounded-[inherit] opacity-0 transition-opacity duration-500 group-hover/tilt:opacity-100"
            style={{
              background:
                "radial-gradient(420px circle at var(--mx,50%) var(--my,50%), rgba(255,255,255,0.10), transparent 45%)",
              transform: "translateZ(1px)",
            }}
          />
        )}
      </motion.div>
    </div>
  );
}
