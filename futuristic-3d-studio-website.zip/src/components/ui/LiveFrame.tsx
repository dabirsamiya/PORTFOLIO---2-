import { useEffect, useRef, useState } from "react";
import { useInView } from "framer-motion";
import { useElementSize } from "@/hooks/useElementSize";
import { cn } from "@/utils/cn";

type Palette = { bg: string; accent: string; text: string };

function luminance(hex: string) {
  const h = hex.replace("#", "");
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
  const n = parseInt(full, 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
}

type Props = {
  url: string;
  name: string;
  palette: Palette;
  /** Virtual viewport width the site is rendered at, then scaled to fit. */
  viewportWidth?: number;
  /** width / height */
  aspect?: number;
  /** Delay mounting (ms) so the host page paints first. */
  delay?: number;
  className?: string;
};

/**
 * Embeds the REAL live website, rendered at a desktop/mobile viewport width and
 * scaled down to fit its container. The frame is inert (decorative, non-focusable)
 * so it never traps keyboard focus or hijacks scrolling — the "View live project"
 * button is the interactive path. A branded skeleton poster shows until loaded.
 */
export function LiveFrame({
  url,
  name,
  palette,
  viewportWidth = 1440,
  aspect = 16 / 10,
  delay = 0,
  className,
}: Props) {
  const { ref: sizeRef, width } = useElementSize<HTMLDivElement>();
  const rootRef = useRef<HTMLDivElement | null>(null);
  const inView = useInView(rootRef, { once: true, margin: "600px 0px" });
  const [mount, setMount] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!inView) return;
    const t = window.setTimeout(() => setMount(true), delay);
    return () => window.clearTimeout(t);
  }, [inView, delay]);

  const scale = width > 0 ? width / viewportWidth : 0;
  const vh = viewportWidth / aspect;
  const isLight = luminance(palette.bg) > 0.5;

  return (
    <div
      ref={(el) => {
        rootRef.current = el;
        sizeRef.current = el;
      }}
      className={cn("relative h-full w-full overflow-hidden", className)}
      style={{ background: palette.bg, containerType: "inline-size" }}
    >
      {/* Branded skeleton poster (visible until the live site paints) */}
      <div
        aria-hidden="true"
        className={cn(
          "absolute inset-0 flex flex-col transition-opacity duration-700",
          loaded ? "opacity-0" : "opacity-100",
        )}
        style={{ color: palette.text }}
      >
        <div className="flex items-center justify-between px-[5%] py-[3%]">
          <span className="font-display text-[clamp(0.6rem,1.6cqw,1rem)] font-extrabold uppercase tracking-tight">
            {name}
          </span>
          <div className="flex gap-[3%] opacity-40">
            {[0, 1, 2, 3].map((i) => (
              <span key={i} className="h-[3px] w-[clamp(12px,3cqw,32px)] rounded-full bg-current" />
            ))}
          </div>
        </div>
        <div className="flex flex-1 items-center px-[5%]">
          <div className="w-1/2 space-y-[4%]">
            <div className="h-[4%] w-1/3 rounded-full" style={{ background: palette.accent, opacity: 0.6 }} />
            <div className="h-[8%] w-11/12 rounded-sm bg-current opacity-20" />
            <div className="h-[8%] w-3/4 rounded-sm bg-current opacity-20" />
            <div className="h-[8%] w-2/5 rounded-sm bg-current opacity-20" />
            <div className="mt-[6%] h-[10%] w-1/3 rounded-sm" style={{ background: palette.accent, opacity: 0.9 }} />
          </div>
          <div
            className="ml-auto aspect-[4/5] w-[34%] rounded-[3px]"
            style={{
              background: `linear-gradient(160deg, ${palette.accent}55, ${isLight ? "#00000010" : "#ffffff10"})`,
            }}
          />
        </div>
        <div className="absolute inset-x-0 bottom-0 flex items-center justify-center pb-[4%]">
          <span
            className="inline-flex items-center gap-2 rounded-[3px] px-3 py-1.5 font-mono text-[0.55rem] tracking-[0.25em] uppercase"
            style={{
              background: isLight ? "rgba(0,0,0,0.06)" : "rgba(255,255,255,0.08)",
              color: palette.text,
            }}
          >
            <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full" style={{ background: palette.accent }} />
            Loading live preview
          </span>
        </div>
      </div>

      {mount && scale > 0 && (
        <iframe
          src={url}
          title={`Live preview of ${name}`}
          aria-hidden="true"
          tabIndex={-1}
          inert
          loading="lazy"
          scrolling="no"
          referrerPolicy="no-referrer-when-downgrade"
          onLoad={() => setLoaded(true)}
          className={cn(
            "pointer-events-none absolute left-0 top-0 border-0 bg-transparent transition-opacity duration-700",
            loaded ? "opacity-100" : "opacity-0",
          )}
          style={{
            width: viewportWidth,
            height: vh,
            transform: `scale(${scale})`,
            transformOrigin: "top left",
          }}
        />
      )}
    </div>
  );
}
