import type { AnchorHTMLAttributes, ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/utils/cn";
import { Magnetic } from "./Magnetic";

type Variant = "primary" | "ghost" | "outline";

const base =
  "group relative inline-flex items-center justify-center gap-3 overflow-hidden rounded-[4px] px-7 py-4 font-mono text-[0.7rem] font-medium uppercase tracking-[0.22em] transition-[transform,box-shadow,border-color,background-color] duration-500 ease-out-expo will-change-transform select-none";

const variants: Record<Variant, string> = {
  primary:
    "bg-[linear-gradient(180deg,#ffffff_0%,#e9ecf6_100%)] text-ink shadow-[0_10px_40px_-10px_rgba(255,255,255,0.35),inset_0_-1px_0_rgba(0,0,0,0.12)] hover:shadow-[0_18px_60px_-12px_rgba(91,140,255,0.55)] hover:-translate-y-0.5",
  outline:
    "glass text-frost hover:border-white/30 hover:bg-white/[0.08] hover:-translate-y-0.5 shadow-[0_10px_30px_-16px_rgba(0,0,0,0.8)]",
  ghost: "text-frost hover:text-white px-0 py-2 tracking-[0.25em]",
};

function Inner({ children, variant }: { children: ReactNode; variant: Variant }) {
  return (
    <>
      {variant === "primary" && (
        <span
          aria-hidden="true"
          className="pointer-events-none absolute inset-y-0 left-0 w-1/3 bg-gradient-to-r from-transparent via-white/90 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100 group-hover:animate-shimmer"
        />
      )}
      {variant === "outline" && (
        <span
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-[radial-gradient(120px_60px_at_var(--mx,50%)_var(--my,50%),rgba(91,140,255,0.25),transparent_70%)] opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        />
      )}
      <span className="relative z-10 flex items-center gap-3">
        {children}
        <svg
          aria-hidden="true"
          viewBox="0 0 24 24"
          className="h-3.5 w-3.5 -translate-x-0.5 transition-transform duration-500 ease-out-expo group-hover:translate-x-0.5"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M5 12h14M13 6l6 6-6 6" />
        </svg>
      </span>
    </>
  );
}

type LinkProps = { href: string; variant?: Variant; magnetic?: boolean; children: ReactNode } & Omit<
  AnchorHTMLAttributes<HTMLAnchorElement>,
  "href" | "children"
>;

export function ButtonLink({ href, variant = "primary", magnetic = true, children, className, ...rest }: LinkProps) {
  const external = /^https?:\/\//.test(href);
  const el = (
    <a
      href={href}
      className={cn(base, variants[variant], className)}
      onPointerMove={(e) => {
        const r = e.currentTarget.getBoundingClientRect();
        e.currentTarget.style.setProperty("--mx", `${e.clientX - r.left}px`);
        e.currentTarget.style.setProperty("--my", `${e.clientY - r.top}px`);
      }}
      {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
      {...rest}
    >
      <Inner variant={variant}>{children}</Inner>
    </a>
  );
  return magnetic ? <Magnetic>{el}</Magnetic> : el;
}

type BtnProps = { variant?: Variant; magnetic?: boolean; children: ReactNode } & ButtonHTMLAttributes<HTMLButtonElement>;

export function Button({ variant = "primary", magnetic = true, children, className, ...rest }: BtnProps) {
  const el = (
    <button className={cn(base, variants[variant], className)} {...rest}>
      <Inner variant={variant}>{children}</Inner>
    </button>
  );
  return magnetic ? <Magnetic>{el}</Magnetic> : el;
}
