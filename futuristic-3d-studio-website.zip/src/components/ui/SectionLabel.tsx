import { cn } from "@/utils/cn";

export function SectionLabel({
  index,
  children,
  className,
}: {
  index?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex items-center gap-4", className)}>
      {index && <span className="font-mono text-[0.68rem] tracking-[0.3em] text-electric">{index}</span>}
      <span className="h-px w-10 bg-gradient-to-r from-white/40 to-transparent" />
      <span className="eyebrow">{children}</span>
    </div>
  );
}

export function FloatChip({
  children,
  className,
  dot = "bg-electric",
}: {
  children: React.ReactNode;
  className?: string;
  dot?: string;
}) {
  return (
    <div
      className={cn(
        "glass-strong metal-edge inline-flex items-center gap-2.5 rounded-[4px] px-3.5 py-2 font-mono text-[0.62rem] tracking-[0.28em] text-frost shadow-[0_20px_40px_-20px_rgba(0,0,0,0.9)]",
        className,
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full shadow-[0_0_10px_currentColor]", dot)} />
      {children}
    </div>
  );
}
