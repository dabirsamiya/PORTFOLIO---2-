import { useRef, type ReactNode } from "react";
import { motion, useInView, type Variants } from "framer-motion";
import { useFitText } from "@/hooks/useFitText";
import { cn } from "@/utils/cn";

const variants: Variants = {
  hidden: { opacity: 0, y: 48, rotateX: 10, filter: "blur(6px)" },
  show: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    rotateX: 0,
    filter: "blur(0px)",
    transition: { duration: 1, delay, ease: [0.16, 1, 0.3, 1] },
  }),
};

/** Scroll-triggered depth reveal (rises from below with a slight perspective tilt). */
export function Reveal({
  children,
  className,
  delay = 0,
  amount = 0.25,
  as = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  amount?: number;
  as?: "div" | "section" | "li" | "p" | "h2" | "h3" | "span";
}) {
  const Comp = motion[as] as typeof motion.div;
  return (
    <div className="perspective-mid">
      <Comp
        className={cn("preserve-3d", className)}
        variants={variants}
        custom={delay}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, amount }}
        style={{ transformOrigin: "50% 100%" }}
      >
        {children}
      </Comp>
    </div>
  );
}

/**
 * Line-by-line masked text reveal for display headings.
 * The (unclipped) heading element is observed — not the clipped children — so the
 * reveal triggers reliably.
 */
const DISPLAY_FONT = '800 100px "Syne", ui-sans-serif, system-ui, sans-serif';

export function RevealLines({
  lines,
  className,
  lineClassName,
  delay = 0,
  as: Tag = "h2",
  id,
  fit,
}: {
  lines: ReactNode[];
  className?: string;
  lineClassName?: string;
  delay?: number;
  as?: "h1" | "h2" | "h3" | "p";
  id?: string;
  /** Fit the longest line to the heading's width so line breaks land exactly as designed. */
  fit?: { longest: string; min?: number; max?: number };
}) {
  const ref = useRef<HTMLHeadingElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.4 });
  const fitted = useFitText(ref, {
    mustFit: fit ? [fit.longest.toUpperCase()] : [],
    font: DISPLAY_FONT,
    letterSpacingEm: -0.03,
    min: fit?.min ?? 34,
    max: fit?.max ?? 120,
  });
  return (
    <Tag id={id} className={className} ref={ref as never} style={fit && fitted ? { fontSize: fitted } : undefined}>
      {lines.map((line, i) => (
        <span key={i} className="block overflow-hidden pb-[0.08em] -mb-[0.08em]">
          <motion.span
            className={cn("block will-change-transform", lineClassName)}
            initial={{ y: "115%", rotateX: -40 }}
            animate={inView ? { y: 0, rotateX: 0 } : { y: "115%", rotateX: -40 }}
            transition={{ duration: 1.1, delay: delay + i * 0.1, ease: [0.16, 1, 0.3, 1] }}
            style={{ transformOrigin: "50% 100%" }}
          >
            {line}
          </motion.span>
        </span>
      ))}
    </Tag>
  );
}
