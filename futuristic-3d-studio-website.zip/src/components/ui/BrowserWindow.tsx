import type { ReactNode } from "react";
import { motion, type MotionStyle } from "framer-motion";
import { cn } from "@/utils/cn";

type Props = {
  url?: string;
  children: ReactNode;
  className?: string;
  style?: MotionStyle;
  /** Depth of the physical frame in px */
  depth?: number;
  /** Extra floating elements rendered inside the 3D space (they can use translateZ). */
  float?: ReactNode;
  glow?: "electric" | "violet" | "warm" | "none";
  compact?: boolean;
};

const glows = {
  electric: "rgba(91,140,255,0.35)",
  violet: "rgba(139,108,255,0.32)",
  warm: "rgba(197,168,128,0.30)",
  none: "transparent",
};

/**
 * A physical, floating 3D browser window: metallic frame, back-plate thickness,
 * layered shadows, glass reflection and a floor glow. Transforms are supplied by
 * the parent through `style` (motion values), so it composes with scroll/mouse.
 */
export function BrowserWindow({ url, children, className, style, depth = 18, float, glow = "electric", compact }: Props) {
  let host = "";
  try {
    host = url ? new URL(url).host : "";
  } catch {
    host = url ?? "";
  }

  return (
    <motion.div className={cn("preserve-3d relative will-change-transform", className)} style={style}>
      {/* Back plate / thickness */}
      <div
        aria-hidden="true"
        className="absolute inset-0 rounded-[12px] bg-[linear-gradient(135deg,#232838,#0a0c12_60%)]"
        style={{ transform: `translateZ(-${depth}px)`, boxShadow: "0 60px 120px -30px rgba(0,0,0,0.85)" }}
      />
      {/* Floor glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-[18%] left-[8%] right-[8%] h-[40%] opacity-90"
        style={{
          transform: `translateZ(-${depth * 2}px)`,
          background: `radial-gradient(ellipse at 50% 100%, ${glows[glow]}, transparent 65%)`,
        }}
      />

      {/* Frame */}
      <div
        className="metal-edge relative overflow-hidden rounded-[12px] bg-ink-2"
        style={{
          transform: "translateZ(0.5px)",
          boxShadow:
            "0 1px 0 rgba(255,255,255,0.06) inset, 0 30px 80px -20px rgba(0,0,0,0.9), 0 10px 30px -10px rgba(0,0,0,0.6)",
        }}
      >
        {/* Chrome bar */}
        <div
          className={cn(
            "relative flex items-center gap-3 border-b border-white/[0.07] bg-[linear-gradient(180deg,#171a24,#10121a)] px-3.5",
            compact ? "h-8" : "h-10 sm:h-11",
          )}
        >
          <div className="flex gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-[#3a3f4d] shadow-[inset_0_1px_1px_rgba(255,255,255,0.15)]" />
            <span className="h-2.5 w-2.5 rounded-full bg-[#3a3f4d] shadow-[inset_0_1px_1px_rgba(255,255,255,0.15)]" />
            <span className="h-2.5 w-2.5 rounded-full bg-[#3a3f4d] shadow-[inset_0_1px_1px_rgba(255,255,255,0.15)]" />
          </div>
          <div className="mx-auto flex h-[60%] w-[56%] max-w-[420px] items-center justify-center gap-2 rounded-[4px] border border-white/[0.06] bg-black/30 px-3">
            {host && (
              <svg
                aria-hidden="true"
                viewBox="0 0 24 24"
                className="h-2.5 w-2.5 shrink-0 text-fog"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.2"
              >
                <rect x="5" y="11" width="14" height="10" rx="2" />
                <path d="M8 11V8a4 4 0 0 1 8 0v3" />
              </svg>
            )}
            <span className="truncate font-mono text-[0.58rem] tracking-wider text-fog">{host || "—"}</span>
          </div>
          <div className="hidden gap-2.5 sm:flex">
            <span className="h-1.5 w-4 rounded-full bg-white/10" />
            <span className="h-1.5 w-1.5 rounded-full bg-white/10" />
          </div>
        </div>

        {/* Viewport */}
        <div className="relative isolate aspect-[16/10] w-full overflow-hidden bg-ink-3">
          {children}
          {/* Glass reflection */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 z-10 bg-[linear-gradient(115deg,rgba(255,255,255,0.10)_0%,rgba(255,255,255,0.02)_28%,transparent_45%,transparent_70%,rgba(139,108,255,0.06)_100%)]"
          />
        </div>
      </div>

      {float}
    </motion.div>
  );
}

/** Placeholder viewport for ready-to-replace project slots. */
export function EmptySlot({ label }: { label: string }) {
  return (
    <div className="relative flex h-full w-full items-center justify-center overflow-hidden bg-[linear-gradient(180deg,#0f1219,#0a0c12)]">
      <div
        aria-hidden="true"
        className="absolute inset-0 opacity-[0.35] [background-image:linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] [background-size:40px_40px] [mask-image:radial-gradient(ellipse_at_center,#000_30%,transparent_75%)]"
      />
      <div aria-hidden="true" className="absolute left-1/2 top-1/2 h-40 w-40 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(circle,rgba(91,140,255,0.12),transparent_65%)]" />
      <div className="relative flex flex-col items-center gap-3 text-center">
        <span className="font-display text-2xl font-extrabold uppercase tracking-tight text-white/85 sm:text-3xl">
          {label}
        </span>
        <span className="inline-flex items-center gap-2 rounded-[3px] border border-white/10 bg-white/[0.04] px-3 py-1.5 font-mono text-[0.58rem] tracking-[0.28em] text-fog uppercase">
          <span className="h-1.5 w-1.5 rounded-full bg-fog/60" />
          Ready to replace
        </span>
      </div>
    </div>
  );
}
