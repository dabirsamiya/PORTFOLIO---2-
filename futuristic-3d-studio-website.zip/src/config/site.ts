/**
 * ─────────────────────────────────────────────────────────────
 *  SAMIYA DIGITAL STUDIO — CENTRAL SITE CONFIGURATION
 *
 *  Everything that is personal / changeable lives in this file:
 *  contact channels, project links, navigation and copy.
 *
 *  Nothing here is invented. Empty strings are intentional
 *  placeholders — fill them in and the UI switches to real links
 *  automatically (no other code changes required).
 * ─────────────────────────────────────────────────────────────
 */

export const siteConfig = {
  name: "Samiya Digital Studio",
  shortName: "Samiya",
  role: "Website Designer & Developer",
  tagline: "Websites for businesses that want to be remembered.",
  positioning:
    "Modern, conversion-focused websites designed for businesses that want to stand out online.",
  year: 2026,

  contact: {
    /**
     * WhatsApp number in international format, DIGITS ONLY (no "+", spaces or dashes).
     * Example: "919876543210". Leave empty until you're ready — the WhatsApp
     * buttons will fall back to the contact form instead of a broken link.
     */
    whatsappNumber: "",
    whatsappMessage: "Hi Samiya, I'd like to talk about a website for my business.",

    /** Example: "hello@yourdomain.com" */
    email: "",

    /** Instagram handle WITHOUT the "@". Example: "samiyadigitalstudio" */
    instagram: "",
  },

  nav: [
    { label: "Work", href: "#work" },
    { label: "Services", href: "#services" },
    { label: "Process", href: "#process" },
    { label: "About", href: "#about" },
    { label: "Contact", href: "#contact" },
  ],

  footerNav: [
    { label: "Work", href: "#work" },
    { label: "Services", href: "#services" },
    { label: "Process", href: "#process" },
    { label: "Contact", href: "#contact" },
  ],
} as const;

/* ─── Projects ──────────────────────────────────────────────── */

export type Project = {
  id: string;
  index: string;
  name: string;
  category: string;
  description: string;
  url: string;
  tags: readonly string[];
  /** Loading-poster palette (matches the live site's own colours) */
  palette: { bg: string; accent: string; text: string };
};

export const featuredProject: Project = {
  id: "ayesha-salon",
  index: "01",
  name: "Ayesha Salon & Academy",
  category: "Salon + Beauty Academy Website",
  description:
    "A modern website experience combining salon services, beauty academy courses, student access and online learning.",
  url: "https://ayesha-salon-website-new.dabirlubna.workers.dev/",
  tags: ["Salon", "Academy", "Courses", "Student Experience"],
  palette: { bg: "#111111", accent: "#c5a880", text: "#f8f6f1" },
};

export const secondProject: Project = {
  id: "mellow-beans",
  index: "02",
  name: "Mellow Beans",
  category: "Café Website",
  description:
    "A warm, modern café website presenting the menu, atmosphere and visiting details for a specialty coffee café in Andheri West, Mumbai.",
  url: "https://mellow-beans-vibe.lovable.app",
  tags: ["Café", "Menu", "Atmosphere"],
  palette: { bg: "#fdf8ef", accent: "#6b4a2f", text: "#3d2b1f" },
};

/** Empty, ready-to-replace slots. Not fake projects — clearly labelled placeholders. */
export const upcomingSlots = ["Project 03", "Project 04"] as const;

/* ─── Helpers ───────────────────────────────────────────────── */

export const hasWhatsApp = () => siteConfig.contact.whatsappNumber.trim().length > 0;
export const hasEmail = () => siteConfig.contact.email.trim().length > 0;
export const hasInstagram = () => siteConfig.contact.instagram.trim().length > 0;

export const whatsappLink = (message: string = siteConfig.contact.whatsappMessage) =>
  hasWhatsApp()
    ? `https://wa.me/${siteConfig.contact.whatsappNumber.replace(/\D/g, "")}?text=${encodeURIComponent(message)}`
    : "#contact";

export const emailLink = (subject?: string, body?: string) => {
  if (!hasEmail()) return "#contact";
  const params = new URLSearchParams();
  if (subject) params.set("subject", subject);
  if (body) params.set("body", body);
  const qs = params.toString();
  return `mailto:${siteConfig.contact.email}${qs ? `?${qs}` : ""}`;
};

export const instagramLink = () =>
  hasInstagram() ? `https://instagram.com/${siteConfig.contact.instagram.replace(/^@/, "")}` : "#contact";
